import requests
import base64
from io import BytesIO
from PIL import Image
import google.generativeai as genai
import random
import string

# Cấu hình API key cho Google Gemini
api_key = "AIzaSyBqWqj3jkOfxpzU9dLpvz1QTz32K56_OmM"  # Thay bằng API key của bạn
genai.configure(api_key=api_key)

# Hàm tạo chuỗi ngẫu nhiên
def generate_random_string(length=10):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

# Định nghĩa headers chung
headers = {
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'authorization': '',  # Nếu cần token, thêm vào đây
    'origin': 'https://web.789club.sx',
    'priority': 'u=1, i',
    'referer': 'https://web.789club.sx/',
    'sec-ch-ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
}

# Headers cho POST (thêm content-type)
headers_post = headers.copy()
headers_post['content-type'] = 'application/json; charset=UTF-8'

# Params cho GET captcha
params = {
    'command': 'getCaptcha',
    'sessionId': 'ea589a6601984af3aabf87948a461692',
}

# Tạo username và displayName ngẫu nhiên
username = generate_random_string(10)
displayName = generate_random_string(12)

# Định nghĩa json_data cho POST
json_data = {
    'command': 'registerWebHash',
    'sessionId': 'ea589a6601984af3aabf87948a461692',
    'answer': '',  # Sẽ được cập nhật sau khi giải captcha
    'username': username,
    'password': 'hoang1234.',
    'displayName': displayName,
    'platformId': 4,
    'advId': '',
    'deviceId': 'ZCB0CfY0enUyZl29mEec',
    'os': 'chrome 134.0.0.0',
    'alsoLogin': True,
    'hash': '7ah68f49700d0869291696cc97e968k2',
    'bundle': 'com.gamebai.sunclub',
    'brand': '789.club',
}

# Bước 1: Gọi API GET để lấy captcha
url = "https://api.atpman.net/id"
try:
    # Lấy captcha
    captcha_response = requests.get(url, params=params, headers=headers, timeout=10)
    captcha_response.raise_for_status()

    print("Nội dung trả về từ GET captcha:", captcha_response.text)
    captcha_data = captcha_response.json()

    # Lấy hình ảnh captcha
    base64_image = captcha_data["data"]["image"]
    session_id = captcha_data["data"]["sessionId"]

    # Chuyển base64 thành hình ảnh
    image_data = base64.b64decode(base64_image)
    image = Image.open(BytesIO(image_data))
    image.save("captcha.png")

    # Bước 2: Gửi hình ảnh đến Gemini 2.0 Flash để giải captcha
    with open("captcha.png", "rb") as image_file:
        image_bytes = image_file.read()

    prompt = (
        "Analyze this captcha image with maximum accuracy. "
        "If it contains a mathematical expression (e.g., '13+31=?'), calculate the result and return only the final number. "
        "If it is plain text, extract it exactly as it appears. "
        "Do not repeat the question or include any explanation—just provide the final answer (number or text)."
    )

    model = genai.GenerativeModel("gemini-2.0-flash")
    response = model.generate_content([prompt, {"mime_type": "image/png", "data": image_bytes}])

    captcha_result = response.text.strip()
    print("Kết quả từ Gemini:", captcha_result)
    json_data['answer'] = captcha_result
    post_response = requests.post(url, headers=headers_post, json=json_data, timeout=10)
    post_response.raise_for_status()

    print("Phản hồi sau khi gửi POST:", post_response.text)

except requests.exceptions.RequestException as e:
    print(f"Lỗi khi gửi yêu cầu đến API: {e}")
except ValueError as e:
    print(f"Lỗi phân tích JSON: {e}")
except Exception as e:
    print(f"Lỗi khác: {e}")