import requests
import random
import string

def call(sdt):
    headers = {
        'Accept': 'application/json',
        'Accept-Language': 'vi-VN',
        'Connection': 'keep-alive',
        'Content-Type': 'application/json',
        'DNT': '1',
        'Origin': 'https://onland.tech',
        'Referer': 'https://onland.tech/user/register.html',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }

    def generate_random_email():
        random_string = ''.join(random.choices(string.ascii_lowercase, k=10))
        return f"{random_string}@gmail.com"

    json_data = {
        'phone_number': sdt,
        'password': 'SfmWsesnF3KN@QK',
        'fullname': 'Duy Hoàng',
        'email': generate_random_email(),
        'province': '24',
        'broker': '',
    }

    response = requests.post('https://onland.tech/api/register', headers=headers, json=json_data, verify=False)
    return response