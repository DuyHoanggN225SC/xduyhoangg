import requests

def call(sdt):
    cookies = {
        'con.ses.id': '0f2f6e74-e4af-4c32-896f-81dca5b9a54f',
        'con.unl.lat': '1729443600',
        'con.unl.sc': '1',
        '__cflb': '02DiuD2Xpp2HE9t1eLHr3NcMs9EVG7eT46TwbKRD7mPF2',
        'con.unl.usr.id': '%7B%22key%22%3A%22userId%22%2C%22value%22%3A%223fa60b93-e886-400a-8ad6-4e9c29ca8453%22%2C%22expireDate%22%3A%222025-10-21T12%3A24%3A19.767316Z%22%7D',
        'con.unl.cli.id': '%7B%22key%22%3A%22clientId%22%2C%22value%22%3A%229f37e285-d84e-4339-901d-5cbbc996552d%22%2C%22expireDate%22%3A%222025-10-21T12%3A24%3A19.7673774Z%22%7D',
        '_cfuvid': 'oBTC8VFHM4J_8e_Jobv55sO.dUcYh_1kuV3abtYpOGY-1729488260424-0.0.1.1-604800000',
        'ab.storage.deviceId.2dca22f5-7d0d-4b29-a49e-f61ef2edc6e9': '%7B%22g%22%3A%2230c27776-2fee-92cb-564e-3a92e96fd521%22%2C%22c%22%3A1729488307917%2C%22l%22%3A1729488307917%7D',
    }

    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'vi,vi-VN;q=0.9,en;q=0.8',
        # 'cookie': 'con.ses.id=0f2f6e74-e4af-4c32-896f-81dca5b9a54f; con.unl.lat=1729443600; con.unl.sc=1; __cflb=02DiuD2Xpp2HE9t1eLHr3NcMs9EVG7eT46TwbKRD7mPF2; con.unl.usr.id=%7B%22key%22%3A%22userId%22%2C%22value%22%3A%223fa60b93-e886-400a-8ad6-4e9c29ca8453%22%2C%22expireDate%22%3A%222025-10-21T12%3A24%3A19.767316Z%22%7D; con.unl.cli.id=%7B%22key%22%3A%22clientId%22%2C%22value%22%3A%229f37e285-d84e-4339-901d-5cbbc996552d%22%2C%22expireDate%22%3A%222025-10-21T12%3A24%3A19.7673774Z%22%7D; _cfuvid=oBTC8VFHM4J_8e_Jobv55sO.dUcYh_1kuV3abtYpOGY-1729488260424-0.0.1.1-604800000; ab.storage.deviceId.2dca22f5-7d0d-4b29-a49e-f61ef2edc6e9=%7B%22g%22%3A%2230c27776-2fee-92cb-564e-3a92e96fd521%22%2C%22c%22%3A1729488307917%2C%22l%22%3A1729488307917%7D',
        'dnt': '1',
        'priority': 'u=1, i',
        'referer': 'https://batdongsan.com.vn/sellernet/internal-sign-up',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-arch': '"x86"',
        'sec-ch-ua-bitness': '"64"',
        'sec-ch-ua-full-version': '"124.0.6367.218"',
        'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6367.218"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-model': '""',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua-platform-version': '"15.0.0"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    }

    params = {
        'phoneNumber': sdt,
    }

    response = requests.get(
        'https://batdongsan.com.vn/user-management-service/api/v1/Otp/SendToRegister',
        params=params,
        cookies=cookies,
        headers=headers,
    )
    return response