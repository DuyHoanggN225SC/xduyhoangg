import requests

def call(sdt):
    headers = {
        'Host': 'api.sieu-vaynhanh.com',
        'User-Agent': 'Android',
        'Lang': 'vi_VN',
        'Content-Type': 'application/json; charset=utf-8',
        # 'Content-Length': '78',
        # 'Accept-Encoding': 'gzip, deflate, br',
    }

    json_data = {
        'phone': sdt,
        'mobileType': '2',
        'version': '1.0.9',
        'appCode': 'vaynhanh',
    }

    response = requests.post('https://api.sieu-vaynhanh.com/api/user/app/login/sms', headers=headers, json=json_data, verify=False)
    return response
