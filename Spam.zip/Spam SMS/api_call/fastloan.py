import requests

def call(sdt):
    sdt = "84" + sdt
    sdt = "84" + sdt.replace("840", "")
    headers = {
        'Content-Type': 'application/json;charset=utf-8',
        'token': '123',
        'Charset': 'UTF-8',
        'Accept': '*/*',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4515.131 Mobile Safari/537.36',
        'Connection': 'close',
        # 'Accept-Encoding': 'gzip, deflate',
        'Host': 'fastloan.gyt158.cn',
        # 'Content-Length': '232',
    }

    json_data = {
        'loginDevice': 'asus',
        'operationSystem': 1,
        'loading': True,
        'systemVersion': '7.1.2',
        'appVersion': '0.1.87',
        'mobilenumber': sdt,
        'AppKey': 'App1648175022',
        'sourceType': 1,
        'installSource': 1,
        'sign': '86AEECEC3E3FF49FC73F434EB5573876',
    }

    response = requests.post('https://fastloan.gyt158.cn/login/getSmsCode', headers=headers, json=json_data, verify=False)
    return response