import requests

def call(sdt):
    cookies = {
        'dtCookiefazzbd66': 'v_4_srv_3_sn_F835106146CB5BB6AB6C42DD74890F06_perc_100000_ol_0_mul_1_app-3Aa156527b274862dd_0',
        'ak_bmsc': '0530FBF1711E12D6063CC3C6D3585C99~000000000000000000000000000000~YAAQhlJNGyVz6aWVAQAAwL0e0RuQkX67r8EY+oz+EG/VYEr9ZwevaWFLEedqqnDtWeQ7zJECuy7jVQvnMsTNWeid5nRMWpKnOv3DvnuXpzSyZ2Sp3gzjTe7/mMlObgPV3vkYwzUd8UA0MkJ0+zMR0WaIR7EeltnHw8GEZYU1l7ToLitj/j7NdOrsrvV2vmHYsvzpIPb0gheLSUrqY+dwdTpmLOLESXB9Wec44qfv2raE1sNiyZKwA/7/JUpYkb/VvpoTR+99CTfvcKC9Vq0wOBt16An8EIVJ0E4D93T1uOTbXbXwMfyAyagzPYFfA/QHm1UVbfSWdD5GksNYWfxpSheAmZwyjv3LQCKtiANhjQ9v9kK4wLRtVB9B089Ssf89RsI4xk1xa7AqPpM=',
        'AKA_A2': 'A',
        'bm_mi': '6137F131D7DCF41A59E9B539A2C56708~YAAQE9YsF4UhDaOVAQAAI/wf0RvKosMQShLrHGsly4U3obXwz1+o/BCtqIvjzKty1lU5rdT+kM2f3gdFbFWhGF1aDrNV0u2mRqS84L6CjZo213jJIXh0ONcA89X0h+RCdREj6zau7k4r7nOvdx/epgmZD7X7e6AgWdVfRQBOOSsNCTg22vA2On6egQR4s//2h8TA+wJc3WDkk/CC6dCiV8c4BxKpn+1JmVmRGaoHRmhkEeL/Hzl+uW5vozROs/mPPAYg2oaW3ZyKgLOB8pokIGwo6bBuhTSTV52M/jdoTHSTaD85TrsAfO19R8RBoDl3~1',
        'PIM-SESSION-ID': 'UgGmjy5J1ki4cZfq',
        'authorization': 'yVlvXCuX4OM-oL3nyGqmNPbVcO0',
        'token_type': 'guest',
        'ROUTE': '.api-585d5d445d-m6vv9',
        '_abck': '0F8664DA9B2429FFE58EFB45D0BF6E27~0~YAAQhlJNG8eQ6aWVAQAAo4Yg0Q31g/mTyz9PfN650XEacv9uMuSutqdj4Z1xaqoVkGVEI4v0MnPKBkORFvW5iMon9NyjUfE671JhbY+7JBqaFlBr8aKP6Ab+Kmar6xScwPEDikhHRmtCZU8a2P9or1htwnpsKLcoQzHDPgz+3G2pmwoKtMAc5GVunCteD9n3aIfiBLDbGPwlAvqkGA0HSybZDfJlJzaujjHHRkBA/qC5mPrzyPY0OTdHNOIRLI0Y3mJv4nct1I1iH8B1FYLW8IksvD8ao7svCT8wRaptBB0FAEyhICEviljhogkeO/GlTs8R15SwpKAU4rPufGjxVViaRZfqDZ0sqcV78te3ZEMrOv+gxh7wAbutIBAy6ngFRpGzf5/KvyDhs0VxptCKYpQDsh9DUnI9bZK2jc6dHgEp3zyLifceKQ5EsiaA2GID1DMkBatTcTkdMdJX2Q+doUC18ycFm4Rp5u1b0qa6TZXN5kuH3kFEjTxrykhT1QqIVRYu/cSlV1wOGwg6q4dnaHoe4R3K/UuT3f4FaLT9CIw9kaJJt4yeU4ejuGfw9rjOdZ+fRMSB0GryLid8RxluDQ0RsZi90wCRYrvExzqHEOsa5Mp4EeoBrv3ZGy7Sq1v+VocEnCe6blap9VFyidE2XnNQpgZBUCgS5BRqFJzbM73chO0w4rfNGJAycT+LLmwbbxEImh5ukF0=~-1~-1~-1',
        'bm_sv': '4E44582439B26F6228E61B81AEB8A2CF~YAAQhlJNG8iQ6aWVAQAAo4Yg0Rs/7D2ugB7XiAwBa6CSJ7Y9yCsvATdokRjT3oSgIzaSzCT/0IG8DKqRVWRxkvVCB5c2zT9slGz++llxKzgqzABomACDlYiHut58FfZN2PkQAb3RlD5bnL57OtqkJKJNz8PQ8VA8l8h36sR8/yVlMRW5Ha6ucfP26GzI1GGQOu48SpBd0eB5jB/kbmb5UIPzFUAKXisQJ7LUjUWcwPtrQvufxMkf4rnCCu+bQctneQ==~1',
        'bm_sz': '3476EE22A2873472A3A86B1CC9FED839~YAAQhlJNG8mQ6aWVAQAAo4Yg0RtrUj224hWCWh3SzeIU1ml/K4FnIFFC3/egy/3rHL9MpjA3Edb8agMV6iUoiJAY5ZY33Gbrd9LpQxRAidYR+6LQrlhWcCGnxKaa/iVh6LliPbOw5E++ZHXZf7ISCYqKJGDO0msX/GHwj4gHvTL1m1SvH7+HagOsPwViF2cuk9vShHKRrjAHsjexmfMDTXN5jBOPUz3mLbClNB1CoUwXfTmlbn20kl5EIYuDH7JWDLcbcXtEj77FbyQ8lzC/AyP5Bg9mbipm3MN0WGqQ1M3b5O4FJHmHR7DrsmxNEPqgk65JAH8FieCmEtXAVsSEhNxj2ldK9RHmJw9dLd5kJK1HwGWqJKocvpY5fnUvK2AWaaamjcJqHww7w80/xikTpkiZ5c1iW/oXc8xyANDt4IdROfeAXXYnWjMRT2PHcQVP4YrKuIQ=~4276537~3684144',
    }

    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'vi,en;q=0.9',
        'authorization': 'bearer yVlvXCuX4OM-oL3nyGqmNPbVcO0',
        'cache-control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
        'content-type': 'application/json',
        'expires': '0',
        'if-modified-since': 'Wed, 26 Mar 2025 06:25:31 GMT',
        'origin': 'https://www.watsons.vn',
        'pragma': 'no-cache',
        'priority': 'u=1, i',
        'queue-target': 'https://www.watsons.vn/vi/register',
        'queueit-target': 'https://www.watsons.vn/vi/register',
        'referer': 'https://www.watsons.vn/',
        'sec-ch-ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
        'vary': '*',
        # 'cookie': 'dtCookiefazzbd66=v_4_srv_3_sn_F835106146CB5BB6AB6C42DD74890F06_perc_100000_ol_0_mul_1_app-3Aa156527b274862dd_0; ak_bmsc=0530FBF1711E12D6063CC3C6D3585C99~000000000000000000000000000000~YAAQhlJNGyVz6aWVAQAAwL0e0RuQkX67r8EY+oz+EG/VYEr9ZwevaWFLEedqqnDtWeQ7zJECuy7jVQvnMsTNWeid5nRMWpKnOv3DvnuXpzSyZ2Sp3gzjTe7/mMlObgPV3vkYwzUd8UA0MkJ0+zMR0WaIR7EeltnHw8GEZYU1l7ToLitj/j7NdOrsrvV2vmHYsvzpIPb0gheLSUrqY+dwdTpmLOLESXB9Wec44qfv2raE1sNiyZKwA/7/JUpYkb/VvpoTR+99CTfvcKC9Vq0wOBt16An8EIVJ0E4D93T1uOTbXbXwMfyAyagzPYFfA/QHm1UVbfSWdD5GksNYWfxpSheAmZwyjv3LQCKtiANhjQ9v9kK4wLRtVB9B089Ssf89RsI4xk1xa7AqPpM=; AKA_A2=A; bm_mi=6137F131D7DCF41A59E9B539A2C56708~YAAQE9YsF4UhDaOVAQAAI/wf0RvKosMQShLrHGsly4U3obXwz1+o/BCtqIvjzKty1lU5rdT+kM2f3gdFbFWhGF1aDrNV0u2mRqS84L6CjZo213jJIXh0ONcA89X0h+RCdREj6zau7k4r7nOvdx/epgmZD7X7e6AgWdVfRQBOOSsNCTg22vA2On6egQR4s//2h8TA+wJc3WDkk/CC6dCiV8c4BxKpn+1JmVmRGaoHRmhkEeL/Hzl+uW5vozROs/mPPAYg2oaW3ZyKgLOB8pokIGwo6bBuhTSTV52M/jdoTHSTaD85TrsAfO19R8RBoDl3~1; PIM-SESSION-ID=UgGmjy5J1ki4cZfq; authorization=yVlvXCuX4OM-oL3nyGqmNPbVcO0; token_type=guest; ROUTE=.api-585d5d445d-m6vv9; _abck=0F8664DA9B2429FFE58EFB45D0BF6E27~0~YAAQhlJNG8eQ6aWVAQAAo4Yg0Q31g/mTyz9PfN650XEacv9uMuSutqdj4Z1xaqoVkGVEI4v0MnPKBkORFvW5iMon9NyjUfE671JhbY+7JBqaFlBr8aKP6Ab+Kmar6xScwPEDikhHRmtCZU8a2P9or1htwnpsKLcoQzHDPgz+3G2pmwoKtMAc5GVunCteD9n3aIfiBLDbGPwlAvqkGA0HSybZDfJlJzaujjHHRkBA/qC5mPrzyPY0OTdHNOIRLI0Y3mJv4nct1I1iH8B1FYLW8IksvD8ao7svCT8wRaptBB0FAEyhICEviljhogkeO/GlTs8R15SwpKAU4rPufGjxVViaRZfqDZ0sqcV78te3ZEMrOv+gxh7wAbutIBAy6ngFRpGzf5/KvyDhs0VxptCKYpQDsh9DUnI9bZK2jc6dHgEp3zyLifceKQ5EsiaA2GID1DMkBatTcTkdMdJX2Q+doUC18ycFm4Rp5u1b0qa6TZXN5kuH3kFEjTxrykhT1QqIVRYu/cSlV1wOGwg6q4dnaHoe4R3K/UuT3f4FaLT9CIw9kaJJt4yeU4ejuGfw9rjOdZ+fRMSB0GryLid8RxluDQ0RsZi90wCRYrvExzqHEOsa5Mp4EeoBrv3ZGy7Sq1v+VocEnCe6blap9VFyidE2XnNQpgZBUCgS5BRqFJzbM73chO0w4rfNGJAycT+LLmwbbxEImh5ukF0=~-1~-1~-1; bm_sv=4E44582439B26F6228E61B81AEB8A2CF~YAAQhlJNG8iQ6aWVAQAAo4Yg0Rs/7D2ugB7XiAwBa6CSJ7Y9yCsvATdokRjT3oSgIzaSzCT/0IG8DKqRVWRxkvVCB5c2zT9slGz++llxKzgqzABomACDlYiHut58FfZN2PkQAb3RlD5bnL57OtqkJKJNz8PQ8VA8l8h36sR8/yVlMRW5Ha6ucfP26GzI1GGQOu48SpBd0eB5jB/kbmb5UIPzFUAKXisQJ7LUjUWcwPtrQvufxMkf4rnCCu+bQctneQ==~1; bm_sz=3476EE22A2873472A3A86B1CC9FED839~YAAQhlJNG8mQ6aWVAQAAo4Yg0RtrUj224hWCWh3SzeIU1ml/K4FnIFFC3/egy/3rHL9MpjA3Edb8agMV6iUoiJAY5ZY33Gbrd9LpQxRAidYR+6LQrlhWcCGnxKaa/iVh6LliPbOw5E++ZHXZf7ISCYqKJGDO0msX/GHwj4gHvTL1m1SvH7+HagOsPwViF2cuk9vShHKRrjAHsjexmfMDTXN5jBOPUz3mLbClNB1CoUwXfTmlbn20kl5EIYuDH7JWDLcbcXtEj77FbyQ8lzC/AyP5Bg9mbipm3MN0WGqQ1M3b5O4FJHmHR7DrsmxNEPqgk65JAH8FieCmEtXAVsSEhNxj2ldK9RHmJw9dLd5kJK1HwGWqJKocvpY5fnUvK2AWaaamjcJqHww7w80/xikTpkiZ5c1iW/oXc8xyANDt4IdROfeAXXYnWjMRT2PHcQVP4YrKuIQ=~4276537~3684144',
    }

    params = {
        'formId': 'registrationOTPForm_Web3',
        'lang': 'vi',
        'curr': 'VND',
    }

    json_data = {
        'uid': '',
        'action': 'REGISTRATION',
        'countryCode': '84',
        'target': sdt,
        'type': 'SMS',
    }

    response = requests.post(
        'https://api.watsons.vn/api/v2/wtcvn/otpToken',
        params=params,
        cookies=cookies,
        headers=headers,
        json=json_data,
    )
    return response