import requests

def call(sdt):
    headers = {
        'Host': 'apigw.haivan.com',
        'Accept': 'application/json',
        # 'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'okhttp/3.12.13',
    }

    params = {
        'phone': sdt,
        'channel': '2',
        'language': 'vi',
    }

    response = requests.get('https://apigw.haivan.com/api/get-otp', params=params, headers=headers, verify=False)
    return response
