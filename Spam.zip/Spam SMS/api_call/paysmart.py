import requests

def call(sdt):
    headers = {
    'Host': 'wallet.paysmart.com.vn',
    'Accept': 'application/json',
    'Smp-Os': 'android',
    'Smp-Appversion': '2.105.1',
    'Smp-Deviceid': '1c94d9daa4317033',
    'Smp-Devicemodel': 'ASUS_Z01QD',
    'Smp-Osver': '7.1.2',
    'Smp-Appversioncode': '665',
    'Smp-Bundleid': 'vn.com.paysmart',
    'Smp-Macaddress': '08:00:27:0F:BD:90',
    'Smp-Aaid': 'e28b16bb-2079-480b-ae4e-8862b4896555',
    'Smp-Phoneno': sdt,
    'Smp-Appreqid': '0001721900854874',
    'Smp-Reqtime': '1721900854874',
    'Smp-Checksum': '338b29f2132ea8d965089864952cf06c12f9c92dd31bcda469f2045c9f622f49',
    'Smp-Ipaddress': '172.16.60.15',
    # Already added when you pass json=
    # 'Content-Type': 'application/json',
    # 'Content-Length': '2',
    # 'Accept-Encoding': 'gzip, deflate',
    'User-Agent': 'okhttp/3.14.9',
    }
    
    json_data = {}
    
    response = requests.post(
        'https://wallet.paysmart.com.vn/v1.0/account/signUp/resendOtp',
        headers=headers,
        json=json_data,
        verify=False,
    )
    return response