import requests

def call(sdt):
    headers = {
        'Host': 'api.heyu.asia',
        'Accept': 'application/json, text/plain, */*',
        'X-Access-Token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImFkbWluQHRlc3QuY29tIiwicGFzc3dvcmQiOiJzaGVlcDEyMzQ1Njc4IiwiaWF0IjoxNDc0OTcwMzc3fQ.38hjO99PEhzk1IT8l16zbKemikhPHHAqZzsSw8lmWtE',
        'Goal': '6710',
        'Content-Type': 'application/json;charset=utf-8',
        # 'Content-Length': '171',
        # 'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'okhttp/4.9.2',
    }

    json_data = {
        'phone': sdt,
        'deviceId': '5ec6a6453646d627',
        'regionName': '',
        'modeApp': '',
        'platform': 'android',
        'nativeVersion': '380062',
        'versionCodePush': '',
        'tShoot': 1718765633206,
    }

    response = requests.post('https://api.heyu.asia/api/v2.1/member/send-code', headers=headers, json=json_data, verify=False)
    return response