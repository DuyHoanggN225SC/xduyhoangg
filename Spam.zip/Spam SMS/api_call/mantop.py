import requests

def call(sdt):
    headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'authorization': '1873a7b1c80c4546a848a174c188a885',
        'content-type': 'application/json; charset=utf-8',
        'dnt': '1',
        'origin': 'https://play.man.top',
        'priority': 'u=1, i',
        'referer': 'https://play.man.top/',
        'sec-ch-ua': '"Not;A=Brand";v="24", "Chromium";v="128"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'cross-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    }

    params = {
        'command': 'getOTPCode',
        'type': '1',
        'phone': sdt,
    }

    response = requests.get('https://api.mangee.io/paygate', params=params, headers=headers)
    return response
