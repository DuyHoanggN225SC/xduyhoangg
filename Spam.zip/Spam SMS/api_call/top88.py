import requests
import json

def call(sdt):
    headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'content-type': 'application/json',
        'dnt': '1',
        'origin': 'https://web.top88.vip',
        'priority': 'u=1, i',
        'referer': 'https://web.top88.vip/',
        'sec-ch-ua': '"Not;A=Brand";v="24", "Chromium";v="128"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'cross-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        'x-token': '36b3101f6768c03ef7bba62e40cad86e',
    }

    json_data = {
        'phone': sdt,
        'app_id': 'top88club',
        'fg_id': '1f4c7ac35d04006d173e966a5a657bfe',
    }

    response = requests.post('https://pmbodergw.dsrcgoms.net/otp/send', headers=headers, json=json_data)
    return response