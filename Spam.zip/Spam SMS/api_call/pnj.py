import requests

def call(sdt):
    cookies = {
        'XSRF-TOKEN': 'eyJpdiI6IlNqRnBtOXNtWHFXVGREbVZ4bS9iaGc9PSIsInZhbHVlIjoiQzBwSDcwQUd4dlFtYnZnUStHa0lCSWcwRnR2N21JZUVrWVpGWVNYSWFISEpOelBwdlFZVGxHbFFUb1NEd2x2WkxXd0tQYmg3aU42ckR2c0llNmpVSldWbHEzRlo0Vkt6b3c0WERGS3g0VzFzSlZ1dTZ0MHZubitHZVN1cnVKR2siLCJtYWMiOiI2ZjgyMTg1NzYyOWVlNTA5Y2QyYWIxYmY0MGNhMzFkOTA5MjBhNmQxOWZlZTBkNTgyYTViMTE5N2FhMzc1NTU3IiwidGFnIjoiIn0%3D',
        'mypnj_session': 'eyJpdiI6IjM1Y1doWGV6QmE1U2VxVHJIUS96N3c9PSIsInZhbHVlIjoienl6bDNDdldaem45a05NUVh6UE1uWnhINTRKZXhXRkttRVZXQXNnY2gxa2NXSnpwK29XU0kzRFVMR1RkNXdoOHZsRWQyQm85Zkh1dUZzUmJkSkFMQWJLSVgzTG9wbVpHZjVKUnpMZHpIWVpSQzNmUGVTdTQ5T2FYcUFEWE56OUUiLCJtYWMiOiJjMWFiZmUyZmFmZTA0ZWQxZWU1ZGQ0ODlmZTBkYWQ4ODAzMTg5MGY5MjY3NmI5MTM0NWQwNjBmYjMyMzJlYzA0IiwidGFnIjoiIn0%3D',
    }

    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'max-age=0',
        'content-type': 'application/x-www-form-urlencoded',
        # 'cookie': 'XSRF-TOKEN=eyJpdiI6IlNqRnBtOXNtWHFXVGREbVZ4bS9iaGc9PSIsInZhbHVlIjoiQzBwSDcwQUd4dlFtYnZnUStHa0lCSWcwRnR2N21JZUVrWVpGWVNYSWFISEpOelBwdlFZVGxHbFFUb1NEd2x2WkxXd0tQYmg3aU42ckR2c0llNmpVSldWbHEzRlo0Vkt6b3c0WERGS3g0VzFzSlZ1dTZ0MHZubitHZVN1cnVKR2siLCJtYWMiOiI2ZjgyMTg1NzYyOWVlNTA5Y2QyYWIxYmY0MGNhMzFkOTA5MjBhNmQxOWZlZTBkNTgyYTViMTE5N2FhMzc1NTU3IiwidGFnIjoiIn0%3D; mypnj_session=eyJpdiI6IjM1Y1doWGV6QmE1U2VxVHJIUS96N3c9PSIsInZhbHVlIjoienl6bDNDdldaem45a05NUVh6UE1uWnhINTRKZXhXRkttRVZXQXNnY2gxa2NXSnpwK29XU0kzRFVMR1RkNXdoOHZsRWQyQm85Zkh1dUZzUmJkSkFMQWJLSVgzTG9wbVpHZjVKUnpMZHpIWVpSQzNmUGVTdTQ5T2FYcUFEWE56OUUiLCJtYWMiOiJjMWFiZmUyZmFmZTA0ZWQxZWU1ZGQ0ODlmZTBkYWQ4ODAzMTg5MGY5MjY3NmI5MTM0NWQwNjBmYjMyMzJlYzA0IiwidGFnIjoiIn0%3D',
        'origin': 'https://www.pnj.com.vn',
        'priority': 'u=0, i',
        'referer': 'https://www.pnj.com.vn/customer/login',
        'sec-ch-ua': '"Not A(Brand";v="8", "Chromium";v="132", "Microsoft Edge";v="132"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 Edg/132.0.0.0',
    }

    data = {
        '_method': 'POST',
        '_token': '5OhRHQp0cUUyW340z8xD7nfpdthi6KwE9muUfYzl',
        'type': 'sms',
        'phone': sdt,
    }

    response = requests.post('https://www.pnj.com.vn/customer/otp/request', cookies=cookies, headers=headers, data=data)
    return response