import requests

def call(sdt):
    cookies = {
        'sessionChecked': '1719981973',
        'HASAKI_SESSID': '6d4557953b696802721b4ca9927382f8',
        'form_key': '6d4557953b696802721b4ca9927382f8',
        'utm_hsk': '%7B%22utm_source%22%3Anull%2C%22utm_medium%22%3Anull%2C%22utm_campaign%22%3Anull%2C%22utm_term%22%3Anull%7D',
        'PHPSESSID': 'k69jba7nd9m3smk6j0g1kt9966',
    }

    headers = {
        'accept': 'application/json, text/javascript, */*; q=0.01',
        'accept-language': 'vi,vi-VN;q=0.9,en;q=0.8',
        # 'cookie': 'sessionChecked=1719981973; HASAKI_SESSID=6d4557953b696802721b4ca9927382f8; form_key=6d4557953b696802721b4ca9927382f8; utm_hsk=%7B%22utm_source%22%3Anull%2C%22utm_medium%22%3Anull%2C%22utm_campaign%22%3Anull%2C%22utm_term%22%3Anull%7D; PHPSESSID=k69jba7nd9m3smk6j0g1kt9966',
        'dnt': '1',
        'priority': 'u=1, i',
        'referer': 'https://hasaki.vn/',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'x-requested-with': 'XMLHttpRequest',
    }

    params = {
        'api': 'user.verifyUserName',
        'username': sdt,
    }

    response = requests.get('https://hasaki.vn/ajax', params=params, cookies=cookies, headers=headers)
    return response