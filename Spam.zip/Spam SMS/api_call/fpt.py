import requests

def call(sdt):
    headers = {
    'accept': '*/*',
    'accept-language': 'vi,vi-VN;q=0.9,en;q=0.8',
    'apptenantid': 'E6770008-4AEA-4EE6-AEDE-691FD22F5C14',
    'content-type': 'application/json',
    'dnt': '1',
    'order-channel': '1',
    'origin': 'https://fptshop.com.vn',
    'priority': 'u=1, i',
    'referer': 'https://fptshop.com.vn/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    }
    
    json_data = {
        'fromSys': 'WEBKHICT',
        'otpType': '0',
        'phoneNumber': sdt,
    }
    
    response = requests.post('https://papi.fptshop.com.vn/gw/is/user/new-send-verification', headers=headers, json=json_data)
    return response
