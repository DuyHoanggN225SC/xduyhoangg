import requests

def call(sdt):
    headers = {
        'Host': 'api.vitailocvm.com',
        'Troup': 'eyJiYW5CZW5Db2RlIjoiMTEiLCJiYW9OYW1lTmV3IjoiY24ucmcudml0YWlsb2MiLCJpa2RmdWlrZCI6ImV3b3dUQ3ZuUVB5aWVkVGpBV3Bwazg6QVBBOTFiRkRJSlBhbkFZUTd0U2c1YkxrbXk0UE95VUZxTzNEN2hfWTExTDRtUWlMX0h4ZUxISWx0Zm5qX1lWLW85UXlmUjQ1S0Qzd0Nvc0Q5aEcyUVhmcXUyMUZ5U0RQV2RwZVc1VnRCSXdpVkl4ZFBPWW1OVzV1UDN6M1A0VHNJTk1oYU5KbFN1RDMiLCJsaW5nUGFpQ29kZSI6IiIsInByb1VzSWQiOiIiLCJzaGFpZlhpbmdJZCI6IiIsInNob3VKaUNvZGUiOiI1ODQwNzNkNS0yMzA5LTQyZjMtYWVkMC02MjU1MzU5ODAzMTMiLCJ5dVlhbmZpVHlwZSI6ImVuIn0=',
        'Content-Type': 'application/json; charset=UTF-8',
        # 'Content-Length': '100',
        # 'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'okhttp/3.12.13',
        'Connection': 'close',
    }

    data = '{"coderadom":"1","mobile":"sdt","type":"1","verificationCode":"1"}'
    data = data.replace("sdt",sdt)

    response = requests.post('https://api.vitailocvm.com/playsComgur/plebfUnd', headers=headers, data=data, verify=False)
    return response