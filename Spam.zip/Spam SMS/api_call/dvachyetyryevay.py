import requests

def call(sdt):
    sdt = "84" + sdt
    sdt = "84" + sdt.replace("840", "")
    headers = {
        'Content-Type': 'application/json;charset=utf-8',
        'token': '123',
        'Charset': 'UTF-8',
        'Accept': '*/*',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4515.131 Mobile Safari/537.36',
        'Connection': 'close',
        # 'Accept-Encoding': 'gzip, deflate',
        'Host': 'www.24vay.com',
        # 'Content-Length': '112',
    }

    json_data = {
        'loading': True,
        'AppKey': 'App1661753875',
        'sign': '3E9804D4264C4967DBB28195569A3CDB',
        'mobilenumber': sdt,
    }

    response = requests.post('http://www.24vay.com/login/getSmsCode', headers=headers, json=json_data, verify=False)
    return response
