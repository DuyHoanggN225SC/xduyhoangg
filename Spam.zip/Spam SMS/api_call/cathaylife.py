import requests

def call(sdt):
    cookies = {
        'JSESSIONID': 'c6iFrue13XEYMGUk3aZn0lou.06283f0e-f7d1-36ef-bc27-6779aba32e74',
        'TS01f67c5d': '0110512fd728b36ab9dbb343410316a9411fc18cebae5bca2ff46e0bc9d28da07f1ba2460f13479ada7d7d41f4cfa09449a5464711',
        'BIGipServerB2C_http': '!8h1o2Tm2sBBA09gR4wuMnLjIghcvhtJsomA+2eQIXP/SPLd3o4C+aO1nYpmsVcC50fve6JGibR27LA==',
        'TS0173f952': '0110512fd728b36ab9dbb343410316a9411fc18cebae5bca2ff46e0bc9d28da07f1ba2460f13479ada7d7d41f4cfa09449a5464711',
        'INITSESSIONID': '5672c5a5c6b317ab1d3c4e5969a9c2b9',
    }

    headers = {
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'Connection': 'keep-alive',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        # 'Cookie': 'JSESSIONID=c6iFrue13XEYMGUk3aZn0lou.06283f0e-f7d1-36ef-bc27-6779aba32e74; TS01f67c5d=0110512fd728b36ab9dbb343410316a9411fc18cebae5bca2ff46e0bc9d28da07f1ba2460f13479ada7d7d41f4cfa09449a5464711; BIGipServerB2C_http=!8h1o2Tm2sBBA09gR4wuMnLjIghcvhtJsomA+2eQIXP/SPLd3o4C+aO1nYpmsVcC50fve6JGibR27LA==; TS0173f952=0110512fd728b36ab9dbb343410316a9411fc18cebae5bca2ff46e0bc9d28da07f1ba2460f13479ada7d7d41f4cfa09449a5464711; INITSESSIONID=5672c5a5c6b317ab1d3c4e5969a9c2b9',
        'DNT': '1',
        'Origin': 'https://www.cathaylife.com.vn',
        'Referer': 'https://www.cathaylife.com.vn/CPWeb/html/CP/Z1/CPZ1_0100/CPZ10110.html',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }

    data = {
        'memberMap': '{"userName":"wogekeg799@kixotic.com","password":"KG4mnuE@A8Bv","birthday":"01/07/1986","certificateNumber":"0123456719","phone":"'+ sdt +'","email":"wogekeg799@kixotic.com","LINK_FROM":"signUp2","memberID":"","CUSTOMER_NAME":"dsadsadsadsadadas"}',
        'OTP_TYPE': 'P',
        'LANGS': 'vi_VN',
    }

    response = requests.post(
        'https://www.cathaylife.com.vn/CPWeb/servlet/HttpDispatcher/CPZ1_0110/reSendOTP',
        cookies=cookies,
        headers=headers,
        data=data,
    )
    return response