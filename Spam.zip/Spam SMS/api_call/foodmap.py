import requests

def call(sdt):
    cookies = {
        'getLocationPickUp': 'eyJpdiI6ImYyZlwvREREbUJJUUZoT3M4MjdldG5RPT0iLCJ2YWx1ZSI6InFJdGRRNlBYajJpcXJFVE1HTGZtTHc9PSIsIm1hYyI6IjhkMDdhYTcwNjg3MTA5NjcxMDJmODljM2MwZjYxYzExZDA0MzcwZThiNDczZDVmMzRlYjRlY2U1MDAzZTk5MzEifQ%3D%3D',
        'XSRF-TOKEN': 'eyJpdiI6IlwvdmZHOXR3cWJ4VzdpOHNuS1BvUW1RPT0iLCJ2YWx1ZSI6IjJUYzFHS3hpS1dwVWtcL2RmaTlhRGJqMlZyYkhcLzFXWXdUaEw0RDkyU1ZoZk85U2ZMVU1rOXB2QnA5QklFNUhGTCIsIm1hYyI6ImJjNGIxMmNiZjNiMjNlNDMzMmU2OGZlOTkxOWVlMjRlYWVkYzNjMDFlZmI5ZjdlMzIxNzI0Y2E4YzgzZmZjZGMifQ%3D%3D',
        'fleetcart_session': 'eyJpdiI6IkQxRml0d3F1bkFyR2tDb1YwM0xGUFE9PSIsInZhbHVlIjoiU3lRT0JZZEpFd0EzZ3VrWnJ6eHpXbFwvTTFiU0hJY2doVkh1RUYyMXhkeUpjZWxMQnRTOTFqS09zTDZ1djNsWHEiLCJtYWMiOiIxZjkwYjgyYjEzMmJjODVhZGZjZWUxMzc1ZWNmODkwNTI1OWQ0YjU4Njc2OGYzOTdmMjliYzNjMDQwY2ZjNjdiIn0%3D',
    }

    headers = {
        'Accept': '*/*',
        'Accept-Language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'Connection': 'keep-alive',
        # 'Cookie': 'getLocationPickUp=eyJpdiI6ImYyZlwvREREbUJJUUZoT3M4MjdldG5RPT0iLCJ2YWx1ZSI6InFJdGRRNlBYajJpcXJFVE1HTGZtTHc9PSIsIm1hYyI6IjhkMDdhYTcwNjg3MTA5NjcxMDJmODljM2MwZjYxYzExZDA0MzcwZThiNDczZDVmMzRlYjRlY2U1MDAzZTk5MzEifQ%3D%3D; XSRF-TOKEN=eyJpdiI6IlwvdmZHOXR3cWJ4VzdpOHNuS1BvUW1RPT0iLCJ2YWx1ZSI6IjJUYzFHS3hpS1dwVWtcL2RmaTlhRGJqMlZyYkhcLzFXWXdUaEw0RDkyU1ZoZk85U2ZMVU1rOXB2QnA5QklFNUhGTCIsIm1hYyI6ImJjNGIxMmNiZjNiMjNlNDMzMmU2OGZlOTkxOWVlMjRlYWVkYzNjMDFlZmI5ZjdlMzIxNzI0Y2E4YzgzZmZjZGMifQ%3D%3D; fleetcart_session=eyJpdiI6IkQxRml0d3F1bkFyR2tDb1YwM0xGUFE9PSIsInZhbHVlIjoiU3lRT0JZZEpFd0EzZ3VrWnJ6eHpXbFwvTTFiU0hJY2doVkh1RUYyMXhkeUpjZWxMQnRTOTFqS09zTDZ1djNsWHEiLCJtYWMiOiIxZjkwYjgyYjEzMmJjODVhZGZjZWUxMzc1ZWNmODkwNTI1OWQ0YjU4Njc2OGYzOTdmMjliYzNjMDQwY2ZjNjdiIn0%3D',
        'DNT': '1',
        'Referer': 'https://foodmap.asia/collections/di-cho-online',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }

    response = requests.get(f'https://foodmap.asia/register/otp/resend-otp/{sdt}', cookies=cookies, headers=headers)
    return response