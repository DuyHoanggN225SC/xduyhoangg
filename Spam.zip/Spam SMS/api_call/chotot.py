import requests

def call(sdt):
    headers = {
        'accept': '*/*',
        'accept-language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'content-type': 'application/json',
        'dnt': '1',
        'origin': 'https://id.chotot.com',
        'priority': 'u=1, i',
        'referer': 'https://id.chotot.com/',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    }

    json_data = {
        'phone': sdt,
        'type': '',
    }

    response = requests.post('https://gateway.chotot.com/v2/public/auth/send_otp_verify', headers=headers, json=json_data)
    return response