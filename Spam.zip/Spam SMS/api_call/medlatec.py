import requests

def call(sdt):
    cookies = {
        '.Smart.Antiforgery': 'CfDJ8HUn4Mljo59EteCvIogLJbSEDYhQtrM5hOFmu2T9BHzU-ZML16e_YRvujD1YKZyeZZncEi1T_MdOHSg2R4BYwTzOmGnQ0Vlpqp1VYAx4NQJMs2olmI8vUmXX9SrU91cjQ9aZEqR10mgGh0sZNmDe8Do',
        'SERVERID': 'web43_4',
        'view_banner_21': '1',
        '.Smart.Identity': 'CfDJ8HUn4Mljo59EteCvIogLJbRpZEWYJWHUioLH0AitYR2SLi9bJF82iabAF3wHwDSaSuZoKYO08oa3GX39_m7LHS8tZxcVZuBkuvDdv8k1ifXhmrRelmF7GR3XG46v8LrS6VaM-1bcRNBHzDpQoxzPO-bs68bfYQJBkDobi1IkAxaVBYz2WG99xxtumN1ze0lDp7ydC-Z1WcBVhaAxUuhLjure8poPyoHaiUwGC484fWJt5juVVQsYX-e-nIW5AZtP1Z3_iq7YB8lzN1Fae43KGwPQwAKNP1XND7LVhvX2T9d4OoXwPQJFYTPXIOpDT-vugMMFbrAXj-_AjMTEhOwy7uuOY65vFf_fFhmaWuU-JvrOOJRB6LkEBCICiWIoz3YJfpkhyMeIItR-mb5YqDsfCaldpLgojfHiL6dy9V1LhBfH5mQ0K0qVL83-QF8Utd7qatbNyQHtQNmDCm0Om3Gvd7SbejZp53Qv2A_sDM8rNcylYs3d9vVJtMg8vM8f0Px6DNiuoPGRsTk9AfTzkXKYduSzu7K4DBFELICCyeBaOixr5dVec2kzqqJMbu5KiSa1Os0XHvHePZU8ArGT2d7O4kQ',
    }

    headers = {
        'Accept': '*/*',
        'Accept-Language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'Connection': 'keep-alive',
        # 'Cookie': '.Smart.Antiforgery=CfDJ8HUn4Mljo59EteCvIogLJbSEDYhQtrM5hOFmu2T9BHzU-ZML16e_YRvujD1YKZyeZZncEi1T_MdOHSg2R4BYwTzOmGnQ0Vlpqp1VYAx4NQJMs2olmI8vUmXX9SrU91cjQ9aZEqR10mgGh0sZNmDe8Do; SERVERID=web43_4; view_banner_21=1; .Smart.Identity=CfDJ8HUn4Mljo59EteCvIogLJbRpZEWYJWHUioLH0AitYR2SLi9bJF82iabAF3wHwDSaSuZoKYO08oa3GX39_m7LHS8tZxcVZuBkuvDdv8k1ifXhmrRelmF7GR3XG46v8LrS6VaM-1bcRNBHzDpQoxzPO-bs68bfYQJBkDobi1IkAxaVBYz2WG99xxtumN1ze0lDp7ydC-Z1WcBVhaAxUuhLjure8poPyoHaiUwGC484fWJt5juVVQsYX-e-nIW5AZtP1Z3_iq7YB8lzN1Fae43KGwPQwAKNP1XND7LVhvX2T9d4OoXwPQJFYTPXIOpDT-vugMMFbrAXj-_AjMTEhOwy7uuOY65vFf_fFhmaWuU-JvrOOJRB6LkEBCICiWIoz3YJfpkhyMeIItR-mb5YqDsfCaldpLgojfHiL6dy9V1LhBfH5mQ0K0qVL83-QF8Utd7qatbNyQHtQNmDCm0Om3Gvd7SbejZp53Qv2A_sDM8rNcylYs3d9vVJtMg8vM8f0Px6DNiuoPGRsTk9AfTzkXKYduSzu7K4DBFELICCyeBaOixr5dVec2kzqqJMbu5KiSa1Os0XHvHePZU8ArGT2d7O4kQ',
        'DNT': '1',
        'Referer': 'https://medlatec.vn/tin-tuc/cac-loai-thuc-pham-dinh-duong-nhat-ban-khong-nen-bo-qua',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }

    response = requests.get(
        f'https://medlatec.vn/Auth/ReSendOTP?tempOTP=TemplateOTP_Register_SMS&cid=750618&issfor={sdt}&pass=acgXhjPX@QFAS8&_=1718162884323',
        cookies=cookies,
        headers=headers,
    )
    return response
