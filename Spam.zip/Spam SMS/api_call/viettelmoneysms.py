import requests

def call(sdt):
    headers = {
        'Host': 'api8.viettelpay.vn',
        'Product': 'VIETTELPAY',
        'Accept-Language': 'vi',
        'Authority-Party': 'APP',
        'Channel': 'APP',
        'Type-Os': 'android',
        'App-Version': '8.8.24',
        'Os-Version': '11',
        'Imei': 'VTP_2847E5CE33D03D8F8EF038BDC6C4A580',
        'X-Request-Id': '20250330144420',
        'Content-Type': 'application/json; charset=UTF-8',
        # 'Content-Length': '194',
        # 'Accept-Encoding': 'gzip, deflate, br',
        'User-Agent': 'okhttp/4.12.0',
    }

    json_data = {
        'hash': '',
        'identityType': 'msisdn',
        'identityValue': sdt,
        'imei': '',
        'notifyToken': '',
        'otp': 'android',
        'pin': '',
        'transactionId': '',
        'type': 'REGISTER',
        'typeOs': 'android',
        'verifyMethod': 'sms',
    }

    response = requests.post('https://api8.viettelpay.vn/customer/v2/accounts/register', headers=headers, json=json_data, verify=False)
    return response