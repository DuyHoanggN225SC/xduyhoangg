import requests

def call(sdt):
    headers = {
        'Host': 'jlos.jaccs.com.vn:8090',
        'Accept': 'application/json',
        'Language': 'vi',
        'Authorization': 'Bearer eyJhbGciOiJIUzUxMiJ9.eyJUWVBFIjoiQ1VTVE9NRVIiLCJzdWIiOiJqbG9zLWpicG0iLCJpYXQiOjE3MTEzNTQxMjEsImV4cCI6MTg2OTAzNDEyMX0.J6qaj3QxyAOagHYLqJ8kcGs1GG2t3_H7kTcaDWW8yZRj6FOu87qPoeir-P3h1mByqWlQphjgQksWlh1WTnTPYQ',
        'Accept-Language': 'vi',
        'Api-Key': 'CUSTOMERGt2xlnrDSgcH0ctFrFnpkUdd59SfvRFcdjM9hPcehGu3ILWPsxQN1uSKwMyt',
        # Already added when you pass json=
        # 'Content-Type': 'application/json',
        # 'Content-Length': '2',
        # 'Accept-Encoding': 'gzip, deflate, br',
        'User-Agent': 'okhttp/4.10.0',
        'Connection': 'keep-alive',
    }

    params = {
        'phone': sdt,
    }

    json_data = {}

    response = requests.post(
        'https://jlos.jaccs.com.vn:8090/jlos/OTP/send/v3',
        params=params,
        headers=headers,
        json=json_data,
        verify=False,
    )
    return response
