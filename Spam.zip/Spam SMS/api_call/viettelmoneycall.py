import requests

def call(sdt):
    headers = {
        'Host': 'gateway.vietmoney.vn',
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
        # 'Content-Length': '41',
        # 'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'okhttp/4.9.1',
    }

    json_data = {
        'phone': sdt,
        'otpMethod': 'call',
    }

    response = requests.post('https://gateway.vietmoney.vn/digital-svc/v1/auth/signup', headers=headers, json=json_data, verify=False)
    return response

#spam call