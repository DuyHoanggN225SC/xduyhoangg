import requests

def call(sdt):
    headers = {
        'Host': 'api-vncdn.vuiapp.vn',
        'Accept': '*/*',
        'X-Debug-Otp': 'false',
        'X-Format-Money': 'json',
        'Accept-Language': 'vi-VN',
        'X-App-Version': '2.66.0',
        'X-Platform': 'android',
        'X-Device-Id': '5ec6a6453646d627',
        'Content-Type': 'application/json',
        'User-Agent': 'okhttp/4.9.2',
    }

    json_data = [
        {
            'eventName': 'Phone Submitted',
            'originalTimestamp': '2025-03-30T07:22:56.677Z',
            'data': {
                'category': 'register_credential',
                'action': 'submit_phone',
                'name': sdt,
            },
        },
    ]

    response = requests.put('https://api-vncdn.vuiapp.vn/v1/tracking', headers=headers, json=json_data, verify=False)
    print(response.text)

    headers = {
        'Host': 'api-vncdn.vuiapp.vn',
        'Accept': '*/*',
        'X-Debug-Otp': 'false',
        'X-Format-Money': 'json',
        'Accept-Language': 'vi-VN',
        'X-App-Version': '4.39.1',
        'X-Platform': 'android',
        'X-Device-Id': '5acf31b2939d7f74',
        'Content-Type': 'application/json',
        'User-Agent': 'okhttp/4.9.2',
    }

    json_data = {
        'operationName': 'requestVerifyDevice',
        'variables': {
            'payload': {
                'deviceId': '5acf31b2939d7f74',
                'phoneNumber': sdt,
            },
        },
        'query': 'mutation requestVerifyDevice($payload: VerifyDevicePayload) {\n  requestVerifyDevice(payload: $payload) {\n    success\n    isNewDevice\n    warningPopup {\n      title\n      content\n      acceptButton\n      __typename\n    }\n    __typename\n  }\n}\n',
    }

    response = requests.post('https://api-vncdn.vuiapp.vn/graphql', headers=headers, json=json_data, verify=False)
    print(response.text)

    headers = {
        'Host': 'api.segment.io',
        'Content-Type': 'text/plain',
        'User-Agent': 'okhttp/4.9.2',
    }

    data = f'{{"batch":[{{"type":"track","event":"Phone Submitted","properties":{{"category":"register_credential","action":"submit_phone","name":"{sdt}"}},"messageId":"d56fbe5c-3077-4c77-a5f9-b665fe6b738c","timestamp":"2025-03-30T07:22:56.677Z","integrations":{{}},"anonymousId":"4d446325-504d-4708-b614-9a4570406793","userId":"{sdt}","context":{{"app":{{"build":"214582","name":"Vui App","namespace":"vn.vuiapp.m","version":"4.39.1"}},"device":{{"manufacturer":"Samsung","model":"Samsung Galaxy J7 Prime","name":"on7xelte","type":"android"}},"library":{{"name":"@segment/analytics-react-native","version":"2.14.0"}},"locale":"vi-VN","network":{{"cellular":false,"wifi":true}},"os":{{"name":"Android","version":"11"}},"screen":{{"width":1080,"height":1920,"density":3}},"timezone":"Asia/Ho_Chi_Minh","traits":{{}},"instanceId":"2fe3a91e-ae9a-4381-beb7-8bc1470385f4"}},"_metadata":{{"bundled":[],"unbundled":["Mixpanel"],"bundledIds":[]}}}}],"sentAt":"2025-03-30T07:22:57.189Z","writeKey":"fglvWh2pKy8Ryp0Yhb8NCaHrPMS55M1F"}}'

    response = requests.post('https://api.segment.io/v1/b', headers=headers, data=data, verify=False)
    print(response.text)

    headers = {
        'Host': 'api-vncdn.vuiapp.vn',
        'Accept': '*/*',
        'X-Debug-Otp': 'false',
        'X-Format-Money': 'json',
        'Accept-Language': 'vi-VN',
        'X-App-Version': '4.39.1',
        'X-Platform': 'android',
        'X-Device-Id': '5acf31b2939d7f74',
        'Content-Type': 'application/json',
        'User-Agent': 'okhttp/4.9.2',
    }

    json_data = {
        'operationName': 'requestLogin',
        'variables': {
            'payload': {
                'phoneNumber': sdt,
                'otpLength': 6,
                'confirmSharingInformation': True,
            },
        },
        'query': 'mutation requestLogin($payload: RequestLoginPayload!) {\n  requestLogin(payload: $payload) {\n    isNew\n    token\n    debug_otp\n    __typename\n  }\n}\n',
    }

    response = requests.post('https://api-vncdn.vuiapp.vn/graphql', headers=headers, json=json_data, verify=False)
    print(response.text)

    headers = {
        'Host': 'api-vncdn.vuiapp.vn',
        'Content-Type': 'application/json',
        'User-Agent': 'okhttp/4.9.2',
    }

    json_data = [
        {
            'eventName': 'Forget Password OTP Loaded',
            'originalTimestamp': '2025-03-30T07:23:01.797Z',
            'data': {
                'category': 'forgot_password',
                'action': 'load_forget_password_otp',
            },
        },
    ]

    response = requests.put('https://api-vncdn.vuiapp.vn/v1/tracking', headers=headers, json=json_data, verify=False)
    print(response.text)

    headers = {
        'Host': 'api.segment.io',
        'Content-Type': 'text/plain',
        'User-Agent': 'okhttp/4.9.2',
    }

    data = f'{{"batch":[{{"type":"identify","userId":"{sdt}","traits":{{"phone":"{sdt}"}},"messageId":"ae4535bd-5d14-4b07-abc6-1c49a37205fe","timestamp":"2025-03-30T07:23:01.596Z","integrations":{{}},"anonymousId":"4d446325-504d-4708-b614-9a4570406793","context":{{"app":{{"build":"214582","name":"Vui App","namespace":"vn.vuiapp.m","version":"4.39.1"}},"device":{{"manufacturer":"Samsung","model":"Samsung Galaxy J7 Prime","name":"on7xelte","type":"android"}},"library":{{"name":"@segment/analytics-react-native","version":"2.14.0"}},"locale":"vi-VN","network":{{"cellular":false,"wifi":true}},"os":{{"name":"Android","version":"11"}},"screen":{{"width":1080,"height":1920,"density":3}},"timezone":"Asia/Ho_Chi_Minh","traits":{{}},"instanceId":"2fe3a91e-ae9a-4381-beb7-8bc1470385f4"}},"_metadata":{{"bundled":[],"unbundled":["Mixpanel"],"bundledIds":[]}}}},{{"type":"track","event":"Forget Password OTP Loaded","properties":{{"category":"forgot_password","action":"load_forget_password_otp"}},"messageId":"592b04c6-1e8e-4cc8-a55e-03272de8f55e","timestamp":"2025-03-30T07:23:01.797Z","integrations":{{}},"anonymousId":"4d446325-504d-4708-b614-9a4570406793","userId":"{sdt}","context":{{"app":{{"build":"214582","name":"Vui App","namespace":"vn.vuiapp.m","version":"4.39.1"}},"device":{{"manufacturer":"Samsung","model":"Samsung Galaxy J7 Prime","name":"on7xelte","type":"android"}},"library":{{"name":"@segment/analytics-react-native","version":"2.14.0"}},"locale":"vi-VN","network":{{"cellular":false,"wifi":true}},"os":{{"name":"Android","version":"11"}},"screen":{{"width":1080,"height":1920,"density":3}},"timezone":"Asia/Ho_Chi_Minh","traits":{{}},"instanceId":"2fe3a91e-ae9a-4381-beb7-8bc1470385f4"}},"_metadata":{{"bundled":[],"unbundled":["Mixpanel"],"bundledIds":[]}}}},{{"type":"screen","name":"OTP","properties":{{"title":"submit_otp","category":"register_otp"}},"messageId":"607dca97-962f-4cee-9201-0696c1f65ed1","timestamp":"2025-03-30T07:23:01.821Z","integrations":{{}},"anonymousId":"4d446325-504d-4708-b614-9a4570406793","userId":"{sdt}","context":{{"app":{{"build":"214582","name":"Vui App","namespace":"vn.vuiapp.m","version":"4.39.1"}},"device":{{"manufacturer":"Samsung","model":"Samsung Galaxy J7 Prime","name":"on7xelte","type":"android"}},"library":{{"name":"@segment/analytics-react-native","version":"2.14.0"}},"locale":"vi-VN","network":{{"cellular":false,"wifi":true}},"os":{{"name":"Android","version":"11"}},"screen":{{"width":1080,"height":1920,"density":3}},"timezone":"Asia/Ho_Chi_Minh","traits":{{}},"instanceId":"2fe3a91e-ae9a-4381-beb7-8bc1470385f4"}},"_metadata":{{"bundled":[],"unbundled":["Mixpanel"],"bundledIds":[]}}}}],"sentAt":"2025-03-30T07:23:02.490Z","writeKey":"fglvWh2pKy8Ryp0Yhb8NCaHrPMS55M1F"}}'

    response = requests.post('https://api.segment.io/v1/b', headers=headers, data=data, verify=False)
    print(response.text)

    headers = {
        'Host': 'api-vncdn.vuiapp.vn',
        'Accept': '*/*',
        'X-Debug-Otp': 'false',
        'X-Format-Money': 'json',
        'Accept-Language': 'vi-VN',
        'X-App-Version': '2.66.0',
        'X-Platform': 'android',
        'X-Device-Id': '5ec6a6453646d627',
        'Content-Type': 'application/json',
        'User-Agent': 'okhttp/4.9.2',
    }

    json_data = {
        'operationName': 'resendAuthenticationOTP',
        'variables': {
            'payload': {
                'phoneNumber': sdt,
                'otpLength': 6,
                'otpMethod': 'Zns',
            },
        },
        'query': 'mutation resendAuthenticationOTP($payload: RequestResendOtpPayload!) {\n  requestResendOtp(payload: $payload) {\n    otp {\n      success\n      debug_otp\n      retryAfter\n      __typename\n    }\n    debug_otp\n    __typename\n  }\n}\n',
    }

    response = requests.post('https://api-vncdn.vuiapp.vn/graphql', headers=headers, json=json_data, verify=False)
    return response