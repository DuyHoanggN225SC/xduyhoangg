import requests

def call(sdt):
    headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'content-type': 'application/json',
        'dnt': '1',
        'origin': 'https://i.go88.ca',
        'priority': 'u=1, i',
        'referer': 'https://i.go88.ca/',
        'sec-ch-ua': '"Not;A=Brand";v="24", "Chromium";v="128"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'cross-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        'x-token': '1800f1cc5bd6547fa6b0cdafde83e002',
    }

    json_data = {
        'phone': sdt,
        'app_id': 'go88com',
        'fg_id': '1f4c7ac35d04006d173e966a5a657bfe',
    }

    response = requests.post('https://pmbodergw.dsrcgoms.net/otp/send', headers=headers, json=json_data)
    return response
