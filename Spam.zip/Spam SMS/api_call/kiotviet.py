import requests

def call(sdt):
    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'authentication-id': '4ddb0c88-9b75-4f1d-9d47-aa8c07d6e0be',
        'content-type': 'application/json',
        'dnt': '1',
        'origin': 'https://connect.kiotviet.vn',
        'priority': 'u=1, i',
        'referer': 'https://connect.kiotviet.vn/',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    }

    json_data = {
        'phone': sdt,
    }

    response = requests.post('https://api-kvc.kiotviet.vn/api/v1/kvc/send-otp', headers=headers, json=json_data)
    return response