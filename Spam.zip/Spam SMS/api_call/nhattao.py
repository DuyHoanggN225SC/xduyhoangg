import requests

def call(sdt):
    cookies = {
        'xf_vim|mudim-settings': '26',
        'G_ENABLED_IDPS': 'google',
        'nhattao_user': '6610804%2Cefa4f31a3da93eb8a7c2941976fc51944c21efc0',
        'nhattao_session': '6b13ef73ae755e23acbd72f005c08c85',
    }

    headers = {
        'accept': 'application/json, text/javascript, */*; q=0.01',
        'accept-language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        # 'cookie': 'xf_vim|mudim-settings=26; G_ENABLED_IDPS=google; nhattao_user=6610804%2Cefa4f31a3da93eb8a7c2941976fc51944c21efc0; nhattao_session=6b13ef73ae755e23acbd72f005c08c85',
        'dnt': '1',
        'origin': 'https://nhattao.com',
        'priority': 'u=1, i',
        'referer': 'https://nhattao.com/register/verify-phone',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'x-ajax-referer': 'https://nhattao.com/register/verify-phone',
        'x-requested-with': 'XMLHttpRequest',
    }

    data = {
        'request_verify': sdt,
        '_xfConfirm': '1',
        '_xfRequestUri': '/register/verify-phone',
        '_xfNoRedirect': '1',
        '_xfToken': '6610804,1729434579,5e526f1be1c4f10abc354701b8f56f5d5e72096c',
        '_xfResponseType': 'json',
    }

    response = requests.post('https://nhattao.com/account/phones/request-verify', cookies=cookies, headers=headers, data=data)
    return response