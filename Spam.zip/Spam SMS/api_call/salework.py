import requests

def call(sdt):
    cookies = {
        'ct_ps_timestamp': '1729436878',
        'ct_timezone': '7',
        'ct_screen_info': '%7B%22fullWidth%22%3A1348%2C%22fullHeight%22%3A10444%2C%22visibleWidth%22%3A1348%2C%22visibleHeight%22%3A955%7D',
        'apbct_headless': 'false',
        'ct_checked_emails': '0',
        'ct_checkjs': '0',
        'ct_mouse_moved': 'true',
        'ct_pointer_data': '%5B%5B3%2C1055%2C848%5D%2C%5B83%2C1062%2C902%5D%2C%5B113%2C914%2C1063%5D%5D',
        'apbct_timestamp': '1729436840',
        'apbct_site_landing_ts': '1729436840',
        'apbct_prev_referer': 'https%3A%2F%2Fsalework.net%2Fshop-ban-quan-ao-dep-tren-shopee%2F',
        'apbct_page_hits': '1',
        'apbct_cookies_test': '%257B%2522cookies_names%2522%253A%255B%2522apbct_timestamp%2522%252C%2522apbct_site_landing_ts%2522%252C%2522apbct_prev_referer%2522%252C%2522apbct_page_hits%2522%255D%252C%2522check_value%2522%253A%25224077f91a1cf5c4ab0075a82dd95f90d9%2522%257D',
        'apbct_urls': '%7B%22salework.net%2Fshop-ban-quan-ao-dep-tren-shopee%2Fjquery-3.6.0.min.js%22%3A%5B1729436840%5D%7D',
        'apbct_site_referer': 'https%3A%2F%2Fsalework.net%2Fshop-ban-quan-ao-dep-tren-shopee%2F',
        'ct_sfw_pass_key': '6fc3f079d924bd197f627fe551f61b2f0',
        'ct_fkp_timestamp': '1729436879',
        '_ati': '2810090948896',
    }

    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/jxl,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Content-Type': 'application/x-www-form-urlencoded',
        # 'Cookie': 'ct_ps_timestamp=1729436878; ct_timezone=7; ct_screen_info=%7B%22fullWidth%22%3A1348%2C%22fullHeight%22%3A10444%2C%22visibleWidth%22%3A1348%2C%22visibleHeight%22%3A955%7D; apbct_headless=false; ct_checked_emails=0; ct_checkjs=0; ct_mouse_moved=true; ct_pointer_data=%5B%5B3%2C1055%2C848%5D%2C%5B83%2C1062%2C902%5D%2C%5B113%2C914%2C1063%5D%5D; apbct_timestamp=1729436840; apbct_site_landing_ts=1729436840; apbct_prev_referer=https%3A%2F%2Fsalework.net%2Fshop-ban-quan-ao-dep-tren-shopee%2F; apbct_page_hits=1; apbct_cookies_test=%257B%2522cookies_names%2522%253A%255B%2522apbct_timestamp%2522%252C%2522apbct_site_landing_ts%2522%252C%2522apbct_prev_referer%2522%252C%2522apbct_page_hits%2522%255D%252C%2522check_value%2522%253A%25224077f91a1cf5c4ab0075a82dd95f90d9%2522%257D; apbct_urls=%7B%22salework.net%2Fshop-ban-quan-ao-dep-tren-shopee%2Fjquery-3.6.0.min.js%22%3A%5B1729436840%5D%7D; apbct_site_referer=https%3A%2F%2Fsalework.net%2Fshop-ban-quan-ao-dep-tren-shopee%2F; ct_sfw_pass_key=6fc3f079d924bd197f627fe551f61b2f0; ct_fkp_timestamp=1729436879; _ati=2810090948896',
        'DNT': '1',
        'Origin': 'https://salework.net',
        'Referer': 'https://salework.net/register',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }

    data = {
        'username': 'hoangmods',
        'phone': sdt,
        'token': 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxMjc1ODciLCJpYXQiOjE3Mjk0MzY4NTYsImV4cCI6MTcyOTQ0MDQ1Nn0.xCr2Qm60K8T_OCqin9ynBuxn7itkeeE8CRlzTWaeeG8c9QKSLlLNRZz6htED4bP9jcGnoEJr45o1UaKJ_bDCdg',
        'action': 'confirm',
    }

    response = requests.post('https://salework.net/resendVerifyOtp', cookies=cookies, headers=headers, data=data)
    return response
