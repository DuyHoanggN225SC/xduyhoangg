import requests

def call(sdt):
    cookies = {
        '__Host-next-auth.csrf-token': '9fae400bc673aa3337e318a8ccb4e8352824edc645ca53c3e3e29d1fa467c2ef%7C397126c664e41ff39973c5f0f0141301d850e521f8a79b7144ce2b55d047b211',
        '__Secure-next-auth.callback-url': 'https%3A%2F%2Fwww.lottemart.vn',
    }

    headers = {
        'accept': 'application/json',
        'accept-language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'content-type': 'application/json',
        # 'cookie': '__Host-next-auth.csrf-token=9fae400bc673aa3337e318a8ccb4e8352824edc645ca53c3e3e29d1fa467c2ef%7C397126c664e41ff39973c5f0f0141301d850e521f8a79b7144ce2b55d047b211; __Secure-next-auth.callback-url=https%3A%2F%2Fwww.lottemart.vn',
        'dnt': '1',
        'origin': 'https://www.lottemart.vn',
        'priority': 'u=1, i',
        'referer': 'https://www.lottemart.vn/signup?callbackUrl=https://www.lottemart.vn/vi-nsg/product/sai-gon-lager-330ml-x-24-18935012413328-p10826',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    }

    json_data = {
        'username': sdt,
        'case': 'register',
    }

    response = requests.post(
        'https://www.lottemart.vn/v1/p/mart/bos/vi_nsg/V1/mart-sms/sendotp',
        cookies=cookies,
        headers=headers,
        json=json_data,
    )
    return response
