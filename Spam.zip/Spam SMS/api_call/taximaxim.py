import requests

def call(sdt):
    sdt = "84" + sdt[1:] if sdt[0] == '0' else "84"+sdt
    headers = {
        'Host': 'cabinet2-sea.taximaxim.com',
        'Accept': 'application/json',
        'Accept-Charset': 'UTF-8',
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002)',
        'X-Client-Requesttimeout': '10',
        'Dark-Theme': 'false',
        'Url-Scheme': 'maximzakaz',
        'Content-Type': 'application/json; charset=utf-8',
        # 'Content-Length': '106',
        # 'Accept-Encoding': 'gzip, deflate',
        'Traceparent': '00-9e38688fc045ea55cbb0fff0a12ea0da-1750412a8b9e32f5-01',
        'Connection': 'close',
    }

    params = {
        'device': 'asus/ASUS_Z01QD/7.1.2',
        'locale': 'vi-VN',
        'source': 'playmarket',
        'udid': '6453646d6275ec6a',
        'version': '3.15.17',
        'density': 'xhdpi',
        'platform': 'CLAPP_ANDROID',
        'latitude': '20.9794367',
        'radius': '1.0',
        'rt': '071040.830',
        'longitude': '105.7099217',
        'sig': 'e5f72b6b7eb16a08a73cc00aa2e745ee',
    }

    json_data = {
        'locale': 'vi-VN',
        'phone': sdt,
        'type': 'sms',
        'smstoken': 'vEMdSjfFO6R',
        'isDefault': '1',
        'mcc': '452',
    }

    response = requests.post(
        'https://cabinet2-sea.taximaxim.com/0000/Services/Public.svc/api/v2/login/code/sms/send',
        params=params,
        headers=headers,
        json=json_data,
        verify=False,
    )
    return response
