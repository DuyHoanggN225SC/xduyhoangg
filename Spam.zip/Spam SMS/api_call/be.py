import requests

def call(sdt):
    headers = {
        'Host': 'gw.be.com.vn',
        'Http_user_agent': 'Android 734',
        'Content-Type': 'application/json; charset=utf-8',
        # 'Content-Length': '897',
        # 'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'okhttp/4.10.0',
    }

    params = ''

    json_data = {
        'client_id': 'EEBUOvQq7RRJBxJm',
        'access_token': '',
        'device_token': 'eTj7oHFtQxSvnkRv9xKwyq:APA91bFkVqfyA8WifgSNpp0apQBYMG6_VSVFxumMZiMZCgALjPCqhQwHx-WHYSOvXg_oT6RhhnnWvcycJN26UaaBxUUPe8o9t33DRElRdXRNUCAZ6n0e0vwDcF7nAvJF3yWzLJvrsQgD',
        'operator_token': '0b28e008bc323838f5ec84f718ef11e6',
        'login_type': '0',
        'locale': 'vi',
        'version': '2.6.65',
        'app_version': '734',
        'os_version': '0',
        'device_type': '0',
        'device_name': 'asusASUS_Z01QD',
        'customer_package_name': 'xyz.be.customer',
        'ad_id': '584073d5-2309-42f3-aed0-625535980313',
        'unique_device_id': '5ec6a6453646d627',
        'latitude': 0,
        'longitude': 0,
        'phone_no': sdt,
        'country_code': '+84',
        'country': '',
        'source': 'download_source=playstore',
        'term_and_condition': 'Báº±ng viá»\x87c tiáº¿p tá»¥c, Báº¡n Ä\x91á»\x93ng Ã½ vá»\x9bi Quy cháº¿ sÃ\xa0n TMDT, Há»£p Ä\x91á»\x93ng váº\xadn chuyá»\x83n cá»§a be vÃ\xa0 be Ä\x91Æ°á»£c xá»\xad lÃ½ dá»¯ liá»\x87u cÃ¡ nhÃ¢n cá»§a mÃ¬nh.',
        'device_rooted': '1',
        'use_pin': '1',
    }

    response = requests.post(
        'https://gw.be.com.vn/api/v1/be-autos/v4/customer/generate_login_otp',
        params=params,
        headers=headers,
        json=json_data,
        verify=False,
    )
    return response
