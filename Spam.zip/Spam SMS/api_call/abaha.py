import requests

def call(sdt):
    sdt = "84" + sdt
    sdt = "84" + sdt.replace("840", "")
    headers = {
        'Host': 'apiapp.abaha.vn',
        'Accept': 'application/json, text/plain, */*',
        'Authorization': 'AbahaApiBearer hsXjY9No8Zu4fLEHSBzp29gcHTB68pmOJShIfEJEnrIZPql3Zp',
        'Verify_authorization': '1',
        'Content-Type': 'application/x-www-form-urlencoded',
        # 'Content-Length': '66',
        # 'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'okhttp/3.12.12',
        'Connection': 'close',
    }

    params = {
        'device_id': 'Organicfood-5ec6a6453646d627',
        'app_key': 'organicfoodkey2GMTq',
        'os': 'android',
        'os_version': '7.1.2',
        'store': '',
        'device_type': 'asus-msmnile',
        'app_version': '1.0.2',
        'timestamp': '1718765750590',
        'hash_token': '4e0578b9c2ce82a3d7b7f0dc9265d60b',
    }

    data = {
        'username': sdt,
        'country': 'VN',
        'country_code': '+84',
        'type': 'esms',
    }

    response = requests.post('https://apiapp.abaha.vn/apiUser/login_sms', params=params, headers=headers, data=data, verify=False)
    return response
