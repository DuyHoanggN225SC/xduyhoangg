import requests

def call(sdt):
    headers = {
        'Host': 'vaypay88.com',
        'Accept-Language': 'vi',
        'User-Agent': 'android',
        'App-Version': '2.0.0',
        'App-Id': 'A18566',
        'Country': 'Vietnam',
        # 'Accept-Encoding': 'gzip, deflate',
        'Connection': 'close',
    }

    params = {
        'phone': sdt,
        'type': 'LOGIN_OR_REGISTER',
        'sendType': 'VOICE',
    }

    response = requests.get('https://vaypay88.com/api/scone-app/register/otp', params=params, headers=headers, verify=False)
    return response
