import requests

def call(sdt):
    cookies = {
        '__cf_bm': 'mxIAy5ib9Z2k6.mqatrDw6ZLRGb8hd1xopYAcvQoNgs-1722398696-1.0.1.1-abWtWQg4aSKfIf2sBM0zxzok9D3jeoPlEG_3codz9EQsDbMyHAr.Z4TybKS5T6olW22kos6hnJ2qPB0MGSyxdA',
        'builderSessionId': '12a246c1b8fa4dacbb728d422df51425',
        'sca_fg_codes': '[]',
        'avadaIsLogin': '',
    }

    headers = {
        'accept': '*/*',
        'accept-language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'authorization': 'Bearer null',
        'content-type': 'text/plain;charset=UTF-8',
        # 'cookie': '__cf_bm=mxIAy5ib9Z2k6.mqatrDw6ZLRGb8hd1xopYAcvQoNgs-1722398696-1.0.1.1-abWtWQg4aSKfIf2sBM0zxzok9D3jeoPlEG_3codz9EQsDbMyHAr.Z4TybKS5T6olW22kos6hnJ2qPB0MGSyxdA; builderSessionId=12a246c1b8fa4dacbb728d422df51425; sca_fg_codes=[]; avadaIsLogin=',
        'dnt': '1',
        'origin': 'https://new.vinamilk.com.vn',
        'priority': 'u=1, i',
        'referer': 'https://new.vinamilk.com.vn/account/register',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    }

    data = '{"type":"register","phone":"' + sdt + '"}'

    response = requests.post('https://new.vinamilk.com.vn/api/account/getotp', cookies=cookies, headers=headers, data=data)
    return response