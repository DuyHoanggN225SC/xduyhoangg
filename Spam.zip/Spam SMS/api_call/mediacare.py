import requests

def call(sdt):
    cookies = {
        'SERVER': 'nginx2',
        'XSRF-TOKEN': 'eyJpdiI6IkIvT0FnVlhDWVhZYkJkVithaHMxNFE9PSIsInZhbHVlIjoicTNkdmZBZnFTYTZXSzV2RFBTZUJNNGFySDJ3aEwxRjBnNnU0V1dIbklDVEtZT2t3aHBiTEVWOC81eFZxV2w0WkNyWjBOV3dyZ1o4b3BSNkRSZlRFN080V2lrMzdDRHQ4Zm1DU0lseXUyaVBrWFFCQ0hRdFpxQXdJaDU5Z3JkalAiLCJtYWMiOiJiM2I2ZjI0ZmU4ZjIyNTJlZjhhZjI1NzFiMTY4NjZkN2MyYmMyMDZjMTQ2OWQzN2ZkN2M5NjU1YzZmNWZmNDdhIiwidGFnIjoiIn0%3D',
        'medicare_session': 'eyJpdiI6InZRM244MkZoL0hhR2VINjNCY2FrT1E9PSIsInZhbHVlIjoiVXcySEtXZGV4b2dFa2hXMmNCK1hMYUJoTkI3ay81cFB6UW5GZjlHc094V1pZT2Jyc3BuU3RhV29Bb0NnMFlQZFpkNVJFTEkvb3ZmNUd3cUFuVHFTeEhmNkFpbXcxVHFHZ1ZIVkVNenBFck1OLy9FbG8rMERjZGdJb21tZ2ZBMGsiLCJtYWMiOiI2NWZmMWJiYWEyYWQ5MGE0NWQ1OWVkMjljMzU1MjQxYjU2MzBlOWM3NjU2ZDI3MzU2MzBmMTVmODgzYTVmZmZjIiwidGFnIjoiIn0%3D',
    }
    
    headers = {
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'Connection': 'keep-alive',
        'Content-Type': 'application/json',
        # 'Cookie': 'SERVER=nginx2; XSRF-TOKEN=eyJpdiI6IkIvT0FnVlhDWVhZYkJkVithaHMxNFE9PSIsInZhbHVlIjoicTNkdmZBZnFTYTZXSzV2RFBTZUJNNGFySDJ3aEwxRjBnNnU0V1dIbklDVEtZT2t3aHBiTEVWOC81eFZxV2w0WkNyWjBOV3dyZ1o4b3BSNkRSZlRFN080V2lrMzdDRHQ4Zm1DU0lseXUyaVBrWFFCQ0hRdFpxQXdJaDU5Z3JkalAiLCJtYWMiOiJiM2I2ZjI0ZmU4ZjIyNTJlZjhhZjI1NzFiMTY4NjZkN2MyYmMyMDZjMTQ2OWQzN2ZkN2M5NjU1YzZmNWZmNDdhIiwidGFnIjoiIn0%3D; medicare_session=eyJpdiI6InZRM244MkZoL0hhR2VINjNCY2FrT1E9PSIsInZhbHVlIjoiVXcySEtXZGV4b2dFa2hXMmNCK1hMYUJoTkI3ay81cFB6UW5GZjlHc094V1pZT2Jyc3BuU3RhV29Bb0NnMFlQZFpkNVJFTEkvb3ZmNUd3cUFuVHFTeEhmNkFpbXcxVHFHZ1ZIVkVNenBFck1OLy9FbG8rMERjZGdJb21tZ2ZBMGsiLCJtYWMiOiI2NWZmMWJiYWEyYWQ5MGE0NWQ1OWVkMjljMzU1MjQxYjU2MzBlOWM3NjU2ZDI3MzU2MzBmMTVmODgzYTVmZmZjIiwidGFnIjoiIn0%3D',
        'DNT': '1',
        'Origin': 'https://medicare.vn',
        'Referer': 'https://medicare.vn/login',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'X-XSRF-TOKEN': 'eyJpdiI6IkIvT0FnVlhDWVhZYkJkVithaHMxNFE9PSIsInZhbHVlIjoicTNkdmZBZnFTYTZXSzV2RFBTZUJNNGFySDJ3aEwxRjBnNnU0V1dIbklDVEtZT2t3aHBiTEVWOC81eFZxV2w0WkNyWjBOV3dyZ1o4b3BSNkRSZlRFN080V2lrMzdDRHQ4Zm1DU0lseXUyaVBrWFFCQ0hRdFpxQXdJaDU5Z3JkalAiLCJtYWMiOiJiM2I2ZjI0ZmU4ZjIyNTJlZjhhZjI1NzFiMTY4NjZkN2MyYmMyMDZjMTQ2OWQzN2ZkN2M5NjU1YzZmNWZmNDdhIiwidGFnIjoiIn0=',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }
    
    json_data = {
        'mobile': sdt,
        'mobile_country_prefix': '84',
    }
    
    response = requests.post('https://medicare.vn/api/otp', cookies=cookies, headers=headers, json=json_data)
    return response