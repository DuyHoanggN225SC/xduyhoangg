import requests

def call(sdt):
    headers = {
        'Host': 'identity.tekoapis.com',
        'Content-Type': 'application/json; charset=UTF-8',
        # 'Content-Length': '29',
        # 'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'okhttp/4.9.3',
        'Connection': 'close',
    }
    
    params = {
        'client_id': 'ddd94468ab2647889ae93825abdcb775',
    }
    
    json_data = {
        'phone_number': sdt,
    }
    
    response = requests.post(
        'https://identity.tekoapis.com/api/v1/passwordless/send',
        params=params,
        headers=headers,
        json=json_data,
        verify=False,
    )
    return response