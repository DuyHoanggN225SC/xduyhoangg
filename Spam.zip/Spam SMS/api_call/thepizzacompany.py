import requests

def call(sdt):
    cookies = {
        '.Nop.Antiforgery': 'CfDJ8PqJqZGi0GlLs843POzwcT6doK-fkENB3oysHJq_T2Lp8bHIOjrpfWdK56R1CMvOQg0J4LS0zpoATX-rURWB5PGynD9BAPokSm6IIHkgBhYy-cjlv25KkF8w-3ltg3uutxEsPXmCmeBWqf3uCAQ5rvY',
        '.Nop.Customer': '50785a15-005f-4ce8-b8a9-143521acfedf',
        '.Nop.TempData': 'CfDJ8PqJqZGi0GlLs843POzwcT76kvvMYDBiq02AQsoVpS1OWn4LoaLzl45E9v5CMhTFsXFaj64K7uAeb-R_H_ayvnxi8K0m2daazQqK160fOvL5e8tNFp3bTkZeJsMCqGkp7kUH_1vW_jFMh9yQ0EFVBKB6wzW71p_paHE-WnkhggZ8gb8TXnwsKBWkwMYu4fJlOA',
    }

    headers = {
        'Accept': '*/*',
        'Accept-Language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'Connection': 'keep-alive',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        # 'Cookie': '.Nop.Antiforgery=CfDJ8PqJqZGi0GlLs843POzwcT6doK-fkENB3oysHJq_T2Lp8bHIOjrpfWdK56R1CMvOQg0J4LS0zpoATX-rURWB5PGynD9BAPokSm6IIHkgBhYy-cjlv25KkF8w-3ltg3uutxEsPXmCmeBWqf3uCAQ5rvY; .Nop.Customer=50785a15-005f-4ce8-b8a9-143521acfedf; .Nop.TempData=CfDJ8PqJqZGi0GlLs843POzwcT76kvvMYDBiq02AQsoVpS1OWn4LoaLzl45E9v5CMhTFsXFaj64K7uAeb-R_H_ayvnxi8K0m2daazQqK160fOvL5e8tNFp3bTkZeJsMCqGkp7kUH_1vW_jFMh9yQ0EFVBKB6wzW71p_paHE-WnkhggZ8gb8TXnwsKBWkwMYu4fJlOA',
        'DNT': '1',
        'Origin': 'https://thepizzacompany.vn',
        'Referer': 'https://thepizzacompany.vn/Otp',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }

    data = {
        'phone': sdt,
        '__RequestVerificationToken': 'CfDJ8PqJqZGi0GlLs843POzwcT4fyc7PtNgXjdpyE4FXwKqaSyCmj5GAlimMuS_LkT8XjHUN-ZTck3wn-GFSIkI1rwfuMY5WTMUcGbQHWA_0j6oQisMeQeYO32LmSsiVrdyVq63y46N4BrXZVC8eEzlIIXQ',
    }

    response = requests.post('https://thepizzacompany.vn/customer/ResendOtp', cookies=cookies, headers=headers, data=data)
    return response