import requests

def call(sdt):
    headers = {
        'Host': 'api.droppii.com',
        'Accept': 'application/json, text/plain, */*',
        'Full-Version': '1.6.0',
        'App-Version': '1.6.0.1717721622',
        'Os': 'android-25',
        'Deviceid': '5ec6a6453646d627',
        'Content-Type': 'application/json',
        # 'Content-Length': '42',
        # 'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'okhttp/4.11.0',
    }

    params = {
        'loading': 'true',
    }

    json_data = {
        'identify': sdt,
        'type': 'SIGN_UP',
    }

    response = requests.post(
        'https://api.droppii.com/identity-service/v1/app/customer/identity/otp',
        params=params,
        headers=headers,
        json=json_data,
        verify=False,
    )
    return response
