import requests

def call(sdt):
    cookies = {
        'laravel_session': 'gcHSiJr7zoZGgNpCaC9ohXC8uTMg5UzCc1oKKpBJ',
        'XSRF-TOKEN': 'eyJpdiI6Ijc3MStob3F5bGJ6eUlYcGRER2xhbXc9PSIsInZhbHVlIjoiQnZKTHRJUGlxZUtKVWdtVFwveEg5ZW9CemhpRzBnaHBFZFQ0TE5USURrRUowVDk3UGJNek4zYlI0a3dVWFAzM0oiLCJtYWMiOiJlODE3MmI2NDMwZDVjZjhhODAzMDc3ZWE0MDkzMzQ0YWNmNjQzMGFkMjFlODVmZGI2ZjdhZDNkODU0NzM4NmMyIn0%3D',
    }

    headers = {
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'Connection': 'keep-alive',
        'Content-Type': 'application/json;charset=UTF-8',
        # 'Cookie': 'laravel_session=gcHSiJr7zoZGgNpCaC9ohXC8uTMg5UzCc1oKKpBJ; XSRF-TOKEN=eyJpdiI6Ijc3MStob3F5bGJ6eUlYcGRER2xhbXc9PSIsInZhbHVlIjoiQnZKTHRJUGlxZUtKVWdtVFwveEg5ZW9CemhpRzBnaHBFZFQ0TE5USURrRUowVDk3UGJNek4zYlI0a3dVWFAzM0oiLCJtYWMiOiJlODE3MmI2NDMwZDVjZjhhODAzMDc3ZWE0MDkzMzQ0YWNmNjQzMGFkMjFlODVmZGI2ZjdhZDNkODU0NzM4NmMyIn0%3D',
        'DNT': '1',
        'Origin': 'https://vietteltelecom.vn',
        'Referer': 'https://vietteltelecom.vn/dang-nhap',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'X-CSRF-TOKEN': 'vm8KqWa2kNV6VJ3EHplfBCZkGaHaqUqkw8dz3JIh',
        'X-Requested-With': 'XMLHttpRequest',
        'X-XSRF-TOKEN': 'eyJpdiI6Ijc3MStob3F5bGJ6eUlYcGRER2xhbXc9PSIsInZhbHVlIjoiQnZKTHRJUGlxZUtKVWdtVFwveEg5ZW9CemhpRzBnaHBFZFQ0TE5USURrRUowVDk3UGJNek4zYlI0a3dVWFAzM0oiLCJtYWMiOiJlODE3MmI2NDMwZDVjZjhhODAzMDc3ZWE0MDkzMzQ0YWNmNjQzMGFkMjFlODVmZGI2ZjdhZDNkODU0NzM4NmMyIn0=',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }

    json_data = {
        'phone': sdt,
        'typeCode': 'DI_DONG',
        'actionCode': 'myviettel://login_mobile',
        'type': 'otp_login',
    }

    response = requests.post('https://vietteltelecom.vn/api/getOTPLoginCommon', cookies=cookies, headers=headers, json=json_data)
    return response
