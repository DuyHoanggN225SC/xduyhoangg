import requests

def call(sdt):
    cookies = {
        '__cfruid': 'ddb71a27035cf3aef73a58c10f09ffb4b8c9cf13-1721915075',
        'XSRF-TOKEN': 'eyJpdiI6ImhKYXhqcDllczQ1aVlKbTFtNEs5SHc9PSIsInZhbHVlIjoiU0w2NEtrVUJoMXNTc2tCZHE2Q3VBci9QS0piZWRsU1oxRC9ZN2x2cXpicUJjZWxWek9qV1NtNUZhai9ZWTZaMnBnc2hTSU9mdmhmUVR6R0lGM0VNajFiL09GQXZ6Q2JGVmFVd2gvOXE1ZVZ4VGp0SThWZXhNelJQemg0bGlWcWIiLCJtYWMiOiI5N2Q1N2U4MWVlZjdhZjdlYjM3ODRhNjEzYTQ3ZDQ3MWNhYjhkODY4NTNhOGY2MGQyNzA1ZmNlMjkzOGViZmY1IiwidGFnIjoiIn0%3D',
        'sessionid': 'eyJpdiI6InNOelZabHJycGh6ZHhEd2QzWjBWa0E9PSIsInZhbHVlIjoiZWdCM1lqWVhMYjR0LzBKeXU2d0NwYk5iSko5eldTU0VGNTlkakJ5b0dpZmdVd3BVWnphbXNmODhNVUdkekY3UC92OFFCU25KY2gydGZpMEE2V1lzZVRUN09ZWS81cmhGMUw5d1pEbEprdnE5T013OWM1VlZKejI0TzM3ZWlRMDgiLCJtYWMiOiI4YmJlMGVlM2QyNjk3YTk5NzA1MDg4YTUzYTk0MzQyZGQwNjdiZjI2Nzg4MGE5Y2RjOGM4NThmMmM0ODYzMDc2IiwidGFnIjoiIn0%3D',
        'utm_uid': 'eyJpdiI6IlNDbVJNdytVQ0hjbkVUMnVBcnBSdlE9PSIsInZhbHVlIjoiU1NNeGNKSWJ1ZE50OVdHTTFpd2VpaVhQWiswbHA2WGM4U3RIVGo5M3lvR0tBdUtvdWkvQ3o4OUZrVkFpdU5nZ1R6TUIxUyt2NitJRFlZQWgvTTRNWDBQOUFTMVZqTm9aa2x1MXJWUURycjRhV1dOdm8zVEVlZGRvRkxmaEJRaGkiLCJtYWMiOiIwMGVjZGQyMTJiMGNlODdiNTkyYjlkODk2OTgzZGU5MmM2MDVkOTJjNDE4MWYxNmZhMDhhODc0Mjc3Njc5ZDM4IiwidGFnIjoiIn0%3D',
        'ec_cache_utm': 'e903c009-fb9e-3730-5829-2877ef408ffa',
        'ec_etag_utm': 'e903c009-fb9e-3730-5829-2877ef408ffa',
        'ec_etag_client_utm': 'null',
        'ec_etag_client': 'false',
        'ec_cache_client': 'false',
        'ec_cache_client_utm': 'null',
        'jslbrc': 'w.202407251344480f35b9d2-4a8c-11ef-8ee8-963d1abb01c1.H_GS',
        'ec_png_utm': 'e903c009-fb9e-3730-5829-2877ef408ffa',
        'uid': 'e903c009-fb9e-3730-5829-2877ef408ffa',
        'ec_png_client': 'false',
        'client': 'false',
        'ec_png_client_utm': 'null',
        'client_utm': 'null',
    }
    
    headers = {
        'accept': '*/*',
        'accept-language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        # 'cookie': '__cfruid=ddb71a27035cf3aef73a58c10f09ffb4b8c9cf13-1721915075; XSRF-TOKEN=eyJpdiI6ImhKYXhqcDllczQ1aVlKbTFtNEs5SHc9PSIsInZhbHVlIjoiU0w2NEtrVUJoMXNTc2tCZHE2Q3VBci9QS0piZWRsU1oxRC9ZN2x2cXpicUJjZWxWek9qV1NtNUZhai9ZWTZaMnBnc2hTSU9mdmhmUVR6R0lGM0VNajFiL09GQXZ6Q2JGVmFVd2gvOXE1ZVZ4VGp0SThWZXhNelJQemg0bGlWcWIiLCJtYWMiOiI5N2Q1N2U4MWVlZjdhZjdlYjM3ODRhNjEzYTQ3ZDQ3MWNhYjhkODY4NTNhOGY2MGQyNzA1ZmNlMjkzOGViZmY1IiwidGFnIjoiIn0%3D; sessionid=eyJpdiI6InNOelZabHJycGh6ZHhEd2QzWjBWa0E9PSIsInZhbHVlIjoiZWdCM1lqWVhMYjR0LzBKeXU2d0NwYk5iSko5eldTU0VGNTlkakJ5b0dpZmdVd3BVWnphbXNmODhNVUdkekY3UC92OFFCU25KY2gydGZpMEE2V1lzZVRUN09ZWS81cmhGMUw5d1pEbEprdnE5T013OWM1VlZKejI0TzM3ZWlRMDgiLCJtYWMiOiI4YmJlMGVlM2QyNjk3YTk5NzA1MDg4YTUzYTk0MzQyZGQwNjdiZjI2Nzg4MGE5Y2RjOGM4NThmMmM0ODYzMDc2IiwidGFnIjoiIn0%3D; utm_uid=eyJpdiI6IlNDbVJNdytVQ0hjbkVUMnVBcnBSdlE9PSIsInZhbHVlIjoiU1NNeGNKSWJ1ZE50OVdHTTFpd2VpaVhQWiswbHA2WGM4U3RIVGo5M3lvR0tBdUtvdWkvQ3o4OUZrVkFpdU5nZ1R6TUIxUyt2NitJRFlZQWgvTTRNWDBQOUFTMVZqTm9aa2x1MXJWUURycjRhV1dOdm8zVEVlZGRvRkxmaEJRaGkiLCJtYWMiOiIwMGVjZGQyMTJiMGNlODdiNTkyYjlkODk2OTgzZGU5MmM2MDVkOTJjNDE4MWYxNmZhMDhhODc0Mjc3Njc5ZDM4IiwidGFnIjoiIn0%3D; ec_cache_utm=e903c009-fb9e-3730-5829-2877ef408ffa; ec_etag_utm=e903c009-fb9e-3730-5829-2877ef408ffa; ec_etag_client_utm=null; ec_etag_client=false; ec_cache_client=false; ec_cache_client_utm=null; jslbrc=w.202407251344480f35b9d2-4a8c-11ef-8ee8-963d1abb01c1.H_GS; ec_png_utm=e903c009-fb9e-3730-5829-2877ef408ffa; uid=e903c009-fb9e-3730-5829-2877ef408ffa; ec_png_client=false; client=false; ec_png_client_utm=null; client_utm=null',
        'dnt': '1',
        'origin': 'https://vietloan.vn',
        'priority': 'u=1, i',
        'referer': 'https://vietloan.vn/login',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'x-requested-with': 'XMLHttpRequest',
    }
    
    data = {
        '_token': 'ijD0wwiC5layw5Woy50h2fenEb2euA7zdhj6pYZp',
        'data': sdt,
    }
    
    response = requests.post('https://vietloan.vn/restore/phone', cookies=cookies, headers=headers, data=data)
    return response
