import requests

def call(sdt):
    headers = {
    'Host': 'api.cadosa.vn',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json;charset=utf-8',
    # 'Content-Length': '75',
    # 'Accept-Encoding': 'gzip, deflate',
    'User-Agent': 'okhttp/4.9.2',
    'Connection': 'close',
    }
    
    json_data = {
        'codeHex': '4344534069706F69706F21',
        'phone': sdt,
        'type': 'REGISTER',
    }
    
    response = requests.post('https://api.cadosa.vn/v1/otp/generator-otp', headers=headers, json=json_data, verify=False)
    return response