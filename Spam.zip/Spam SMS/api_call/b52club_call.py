import httpx
import asyncio
import random
import string
import json

def random_string(length=10):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

async def call_async(sdt):
    async with httpx.AsyncClient() as client:
        fullname = random_string(12)
        username = random_string(12)
        password = "duyhoanggv2"
        fg = random_string(32)

        headers_register = {
            'accept': '*/*',
            'content-type': 'text/plain;charset=UTF-8',
            'origin': 'https://play.b52.cc',
            'referer': 'https://play.b52.cc/',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
        }

        data_register = json.dumps({
            "fullname": fullname,
            "username": username,
            "password": password,
            "app_id": "b52.club",
            "avatar": "Avatar34",
            "os": "Windows",
            "device": "Computer",
            "browser": "chrome",
            "fg": fg,
            "aff_id": "b52",
            "version": "1.71.1"
        })

        response = await client.post('https://bfivegwlog.gwtenkges.com/user/register.aspx', headers=headers_register, data=data_register)
        response_text = response.text

        try:
            response_text = response_text.encode(response.encoding or 'utf-8').decode('utf-8')
        except (UnicodeEncodeError, TypeError, AttributeError):
            pass  # Giữ nguyên nếu lỗi

        response_json = json.loads(response_text)
        print(response_json)

        if response_json.get("status") == "OK" and response_json.get("code") == 200:
            token = response_json["data"][0]["session_id"]
        else:
            print("Đăng ký thất bại!")
            return

        headers_update = {
            'accept': '*/*',
            'content-type': 'application/json',
            'origin': 'https://play.b52.cc',
            'referer': 'https://play.b52.cc/',
            'user-agent': 'Mozilla/5.0',
            'x-token': token,
        }

        json_update = {
            'fullname': random_string(10),
            'aff_id': '',
        }

        response_update = await client.post('https://bfivegwlog.gwtenkges.com/user/update.aspx', headers=headers_update, json=json_update)
        response_text = response_update.text

        try:
            response_text = response_text.encode(response_update.encoding or 'utf-8').decode('utf-8')
        except (UnicodeEncodeError, TypeError, AttributeError):
            pass  # Giữ nguyên nếu lỗi

        print(json.loads(response_text))

        headers_otp = {
            'accept': '*/*',
            'content-type': 'application/json',
            'origin': 'https://play.b52.cc',
            'referer': 'https://play.b52.cc/',
            'user-agent': 'Mozilla/5.0',
            'x-token': token,
        }

        json_otp = {
            'phone': sdt,
            'app_id': 'b52.club',
            'fg_id': fg,
        }

        response_otp = await client.post('https://bfivegwpeymint.gwtenkges.com/otp/send', headers=headers_otp, json=json_otp)

        if response_otp:
            response_text = response_otp.text
            try:
                response_text = response_text.encode(response_otp.encoding or 'utf-8').decode('utf-8')
            except (UnicodeEncodeError, TypeError, AttributeError):
                pass  # Giữ nguyên nếu lỗi
            print(json.loads(response_text))
        else:
            print("Lỗi: Không nhận được phản hồi từ API")

def call(sdt):
    asyncio.run(call_async(sdt))
