import requests

def call(sdt):
    headers = {
        'accept': 'application/json',
        'accept-language': 'vi',
        'content-type': 'application/json; charset=utf-8',
        'dnt': '1',
        'key': '9ec3da006ac3e7090da9cd18906153dc',
        'origin': 'https://routine.vn',
        'priority': 'u=1, i',
        'referer': 'https://routine.vn/',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'timestamp': '1729436386341',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    }

    json_data = {
        'phoneNumber': sdt,
    }

    response = requests.post(
        'https://ecom-api.routine.vn/client/phone-verification/request-verification',
        headers=headers,
        json=json_data,
        verify=False
    )
    return response