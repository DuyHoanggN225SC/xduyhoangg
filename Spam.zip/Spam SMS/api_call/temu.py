import requests

def call(sdt):
    cookies = {
        'region': '217',
        'language': 'en',
        'currency': 'VND',
        'api_uid': 'Cmzcc2eYMgccDgBHZbtJAg==',
        '__cf_bm': 'nEvscUe24QqCCwALBHJ8SVzcIgwVqvfFvxl6kJ5lrZE-1738027527-1.0.1.1-9V_0tAOfKeAf.xSCQD3BIepppXVwtmCB1qhxSwEUXLP0rqlvpqQR8uyhjTMljL733TCiuFcEBng.Qp943k4vtA',
        'timezone': 'Asia%2FSaigon',
        'webp': '1',
        '_nano_fp': 'Xpmql09xnqdqXqdoXo_s5Wxq1HrZuKl67QxijZr3',
        'verifyAuthToken': 'XctRZ1os8reg-Msl_ZdQ3gdb2a9ecf5bf3b3152',
        '_bee': 'WfKIApTXsDmymYFRcfRPaNnbDv8iDjn6',
        'njrpl': 'WfKIApTXsDmymYFRcfRPaNnbDv8iDjn6',
        'dilx': 'mpzUPKkXAqNHlgbh_MJX0',
        'hfsc': 'L3yJcIky7jv625HOfQ==',
        '_ttc': '3.MYtkyMsopIiZ.1769563529',
    }

    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'en-US,en;q=0.9',
        'anti-content': '0aqWtqlyviKyj9uaTsFmJSmadibsndg54CkaXE3yqDcKrV32xdS_P6LQ16w1IikEtQyD7IrVAg1FG-dWhZBvkVaZGSPmhtwB08K0QGZfSK__xFIw3Uyb1qmmbZ254rFPdraYWiJW0R9t9ZaDlyFTzpJCfBuSu3sgAj157euxYGClsbyo0fHkyM57oRzH6fSLIiplWqkRM-IR4xtCfPTI0t8PHLZxH6Cb9xzaOr47DIn2wUSI9H8TCxnzmsYOsmzO02Z9UzNS5wWa-QV50J4sd0QowbXKfpi40RgnHe9HbsGAVdW9-EOsSyPjXgYiBnaTsKpOJwBBX6oLmAVPThu2V9M_jJEWsYTVrfrJIuEwnvA1R-oKQIQcR--OQ5QvJpRrKHropkxoTcJPGIHhQQM-EHoKIcDr3kGVdYk3YUtiBDol3olWZxFkgqIkE5JqdF3UAt1vikUfDwb1ZvfuorbkZoBFpySBwJt1MGVvBwY3_TfjhQLIU5LkCb3Vgu3-hvFMkQs9ncXCOsEssw3Ka8MR6qpu3aCaNd5K3cP82tH0aJZ_-bpVYam3Pa0XaIuGXEN7o7YTXN2Jxk3uQYaGMz9Pr4JmuqArXf6iv_0NCKiXlTvK3OxG3cMiSvYPQcZ7xFu_BNHFxliYvxrn1-9TpUDIdcWoq434tB1LVxJARJAa5dyCOdO_MI2juxyilM7VmquaPoe-unuzQGGHCiu8_SdCS2Xly7p_5H44SlMG1DG16t7xtXd213u5VomokSQZ0VAqQSPW8jZ3XNS0Ro2RdC6lSweVLHGKqlAMIHhyXDPWLTQSSecBt1enyv7m3aWsjNwJaskfp89Z-0WPV2',
        'content-type': 'application/json;charset=UTF-8',
        # 'cookie': 'region=217; language=en; currency=VND; api_uid=Cmzcc2eYMgccDgBHZbtJAg==; __cf_bm=nEvscUe24QqCCwALBHJ8SVzcIgwVqvfFvxl6kJ5lrZE-1738027527-1.0.1.1-9V_0tAOfKeAf.xSCQD3BIepppXVwtmCB1qhxSwEUXLP0rqlvpqQR8uyhjTMljL733TCiuFcEBng.Qp943k4vtA; timezone=Asia%2FSaigon; webp=1; _nano_fp=Xpmql09xnqdqXqdoXo_s5Wxq1HrZuKl67QxijZr3; verifyAuthToken=XctRZ1os8reg-Msl_ZdQ3gdb2a9ecf5bf3b3152; _bee=WfKIApTXsDmymYFRcfRPaNnbDv8iDjn6; njrpl=WfKIApTXsDmymYFRcfRPaNnbDv8iDjn6; dilx=mpzUPKkXAqNHlgbh_MJX0; hfsc=L3yJcIky7jv625HOfQ==; _ttc=3.MYtkyMsopIiZ.1769563529',
        'origin': 'https://www.temu.com',
        'priority': 'u=1, i',
        'referer': 'https://www.temu.com/?_x_sessn_id=eatno8915f&refer_page_name=bgn_verification&refer_page_id=10017_1738027534836_ugzq2wp1tt&refer_page_sn=10017',
        'sec-ch-ua': '"Not A(Brand";v="8", "Chromium";v="132", "Microsoft Edge";v="132"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 Edg/132.0.0.0',
        'verifyauthtoken': 'XctRZ1os8reg-Msl_ZdQ3gdb2a9ecf5bf3b3152',
        'x-document-referer': 'https://www.temu.com/?_x_sessn_id=eatno8915f&refer_page_name=bgn_verification&refer_page_id=10017_1738027534836_ugzq2wp1tt&refer_page_sn=10017',
        'x-phan-data': '0aeJx7xMxiYPiIuY8x2tDc2MLAyNzUxMjQyFgHwTMzM0fwzA1MLeE8UwNTYySehbm5YSwA4CERbA',
    }

    json_data = {
        'login_app_id': 103,
        'mobile': '0988776655',
        'tel_location_id': 217,
        'tel_code': '84',
        'login_scene': 602,
    }

    response = requests.post(
        'https://www.temu.com/api/bg/sigerus/auth/mobile_code/request',
        cookies=cookies,
        headers=headers,
        json=json_data,
    )
    return response