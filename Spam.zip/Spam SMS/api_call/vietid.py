import requests

def call(sdt):
    cookies = {
            '_ga_H5VRTZBFLG': 'GS1.1.1703391940.3.1.1703392313.0.0.0',
            '_ga': 'GA1.2.148534600.1701706498',
            '_ga_X01Q5JZ5VS': 'GS1.2.1703391941.3.1.1703392314.0.0.0',
            'PHPSESSID': '95c49a18-763c-450d-ba59-7549a2b360c9',
            'PHPSS': '16',
        }
        
    headers = {
            'authority': 'oauth.vietid.net',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            # 'cookie': '_ga_H5VRTZBFLG=GS1.1.1703391940.3.1.1703392313.0.0.0; _ga=GA1.2.148534600.1701706498; _ga_X01Q5JZ5VS=GS1.2.1703391941.3.1.1703392314.0.0.0; PHPSESSID=95c49a18-763c-450d-ba59-7549a2b360c9; PHPSS=16',
            'origin': 'https://oauth.vietid.net',
            'referer': 'https://oauth.vietid.net/vcc/login?reg=true&cb=',
            'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Linux; Android 12; 2201117TG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
        }
        
    params = {
            'reg': 'true',
            'cb': '',
        }
        
    data = {
            'csrf-token': 'kxHQ1qPSIxY',
            'account': sdt,
        }
        
    response = requests.post('https://oauth.vietid.net/vcc/login', params=params, cookies=cookies, headers=headers, data=data)
    return response