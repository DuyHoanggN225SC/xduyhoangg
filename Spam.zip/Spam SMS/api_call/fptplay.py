import requests

def call(sdt):
    headers = {
        'Host': 'api.fptplay.net',
        'St': 'm7nCS--9HEng8f2RoGcnrw',
        'E': '1718249119',
        'User-Agent': 'Mozilla/5.0 (compatible; MSIE 10.0; FPT Play Mobile (version:7.1.2,model:ASUS_Z01QD); Trident/6.0; IEMobile/10.0; ARM; Touch; asus; ASUS_Z01QD)',
        'X-Did': '5ec6a6453646d627',
        'Content-Type': 'application/json; charset=UTF-8',
        # 'Content-Length': '97',
        # 'Accept-Encoding': 'gzip, deflate',
    }

    json_data = {
        'phone': sdt,
        'client_id': 'LVmko1C7tFMMZJUFew4SuMbvbuyYRDRNyzhrqRft',
        'country_code': 'VN',
    }

    response = requests.post(
        'https://api.fptplay.net/api/v7.1_a/user/otp/register_otp?serial_number=&drm_id=&drm=0&fhd=0&st=m7nCS--9HEng8f2RoGcnrw&e=1718249119&version=7.14.8&version_code=1354&source=mobile_normal&uSKBC=true&cachedByUrls=true&nettype=wifi&device=FPT%20Play%20Mobile%20%28version:7.1.2%2Cmodel:ASUS_Z01QD%29&mac_address=&mac_addr=5ec6a6453646d627&deviceWidth=900&deviceHeight=1600',
        headers=headers,
        json=json_data,
        verify=False,
    )
    return response
