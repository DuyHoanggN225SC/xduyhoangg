import requests

def call(sdt):
    headers = {
        'Host': 'api.mobile.vieclam24h.vn',
        'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJjaGFubmVsX2NvZGUiOiJ2bDI0aCIsInVzZXIiOm51bGx9.a0POm2ZVRwetYs2QsMj0sRg8lZSSbKufX4sewqhAM5o',
        'Accept': 'application/json, text/plain, */*',
        'App-Name': 'VIECLAM24H-MOBILE-APP',
        'Lang': 'vi',
        'Os': 'ANDROID',
        'Os-Version': '11',
        'X-Api-Version': '1.0',
        'App-Version': '1.11.0',
        'Content-Type': 'application/json',
        # 'Content-Length': '32',
        # 'Accept-Encoding': 'gzip, deflate, br',
        'User-Agent': 'okhttp/4.9.2',
        'Connection': 'keep-alive',
    }

    json_data = {
        'type': 1,
        'mobile': sdt,
    }

    response = requests.post('https://api.mobile.vieclam24h.vn/seeker/request-otp', headers=headers, json=json_data, verify=False)
    return response
