import requests

def call(sdt):
    cookies = {
        'TBMCookie_3209819802479625248': '793758001717896563gO1HjgaSiV+z9A1f9IlJ72pGLlo=',
        '___utmvm': '###########',
        'DMX_Personal': '%7B%22UID%22%3A%222b00609aff4342373b128ced62744ba97e8ca0ef%22%2C%22ProvinceId%22%3A3%2C%22Address%22%3Anull%2C%22Culture%22%3A%22vi-3%22%2C%22Lat%22%3A0.0%2C%22Lng%22%3A0.0%2C%22DistrictId%22%3A0%2C%22WardId%22%3A0%2C%22StoreId%22%3A0%2C%22CouponCode%22%3Anull%2C%22CRMCustomerId%22%3Anull%2C%22CustomerSex%22%3A-1%2C%22CustomerName%22%3Anull%2C%22CustomerPhone%22%3Anull%2C%22CustomerEmail%22%3Anull%2C%22CustomerIdentity%22%3Anull%2C%22CustomerBirthday%22%3Anull%2C%22CustomerAddress%22%3Anull%2C%22IsDefault%22%3Afalse%2C%22IsFirst%22%3Afalse%7D',
        'mwgngxpv': '3',
        '.AspNetCore.Antiforgery.Pr58635MgNE': 'CfDJ8AFHr2lS7PNCsmzvEMPceBNnWY3P7SxN-ty_aLkv1LREJ9RDCYWXoeUnU9sAHoa7GMY1TrE8F6r6pXGq0LXniBDQ6JG91h6OaQP_z6_mqZSjr32D90mW7iXAIqphu-llokfmDlVAw3NGs5tn59tpdtA',
        'SvID': 'beline2686|ZmUFf|ZmUFd',
    }

    headers = {
        'Accept': '*/*',
        'Accept-Language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'Connection': 'keep-alive',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        # 'Cookie': 'TBMCookie_3209819802479625248=793758001717896563gO1HjgaSiV+z9A1f9IlJ72pGLlo=; ___utmvm=###########; DMX_Personal=%7B%22UID%22%3A%222b00609aff4342373b128ced62744ba97e8ca0ef%22%2C%22ProvinceId%22%3A3%2C%22Address%22%3Anull%2C%22Culture%22%3A%22vi-3%22%2C%22Lat%22%3A0.0%2C%22Lng%22%3A0.0%2C%22DistrictId%22%3A0%2C%22WardId%22%3A0%2C%22StoreId%22%3A0%2C%22CouponCode%22%3Anull%2C%22CRMCustomerId%22%3Anull%2C%22CustomerSex%22%3A-1%2C%22CustomerName%22%3Anull%2C%22CustomerPhone%22%3Anull%2C%22CustomerEmail%22%3Anull%2C%22CustomerIdentity%22%3Anull%2C%22CustomerBirthday%22%3Anull%2C%22CustomerAddress%22%3Anull%2C%22IsDefault%22%3Afalse%2C%22IsFirst%22%3Afalse%7D; mwgngxpv=3; .AspNetCore.Antiforgery.Pr58635MgNE=CfDJ8AFHr2lS7PNCsmzvEMPceBNnWY3P7SxN-ty_aLkv1LREJ9RDCYWXoeUnU9sAHoa7GMY1TrE8F6r6pXGq0LXniBDQ6JG91h6OaQP_z6_mqZSjr32D90mW7iXAIqphu-llokfmDlVAw3NGs5tn59tpdtA; SvID=beline2686|ZmUFf|ZmUFd',
        'DNT': '1',
        'Origin': 'https://www.thegioididong.com',
        'Referer': 'https://www.thegioididong.com/lich-su-mua-hang/dang-nhap',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }

    data = {
        'phoneNumber': sdt,
        'isReSend': 'false',
        'sendOTPType': '1',
        '__RequestVerificationToken': 'CfDJ8AFHr2lS7PNCsmzvEMPceBOHpRBoJWH3_P7CP6d_A8BDLwXhr0z7BiwP5gc-G3EZfXuGDucU98raKpnp7K5xJn0Ia8BVCwx2W-bF1hFiWZcyosAFDH53-En_e82HeTX5XpByNkCdDAK1AQlwHm3230A',
    }

    response = requests.post(
        'https://www.thegioididong.com/lich-su-mua-hang/LoginV2/GetVerifyCode',
        cookies=cookies,
        headers=headers,
        data=data,
    )
    return response
