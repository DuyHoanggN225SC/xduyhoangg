import requests

def call(sdt):
    headers = {
            'Host': 'api.gapowork.vn',
            'Accept': 'application/json; charset=utf-8',
            'X-Gapo-Lang': 'vi',
            'User-Agent': 'GapoWork/4.5.2 (Android 7.1.2; ASUS_Z01QD; asus ASUS_l001_1)',
            'Content-Type': 'application/json; charset=UTF-8',
            # 'Content-Length': '127',
            # 'Accept-Encoding': 'gzip, deflate',
        }

    json_data = {
            'phone_number': sdt,
            'device_id': 'a2d58cb7-606f-4ec9-9e0e-0efa1711f807',
            'device_model': 'ASUS_Z01QD',
            'new_domain': False,
        }

    response = requests.post('https://api.gapowork.vn/auth/v3.1/signup', headers=headers, json=json_data, verify=False)
    return response
