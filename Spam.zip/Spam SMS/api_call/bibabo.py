import requests

def call(sdt):
    headers = {
        'Host': 'one.bibabo.vn',
        'Accept': 'application/json, text/plain, */*',
        # 'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'okhttp/4.9.2',
        'Connection': 'close',
    }

    params = {
        'phone': sdt,
        'reCaptchaToken': 'undefined',
        'appId': '7',
        'version': '2',
    }

    response = requests.get('https://one.bibabo.vn/api/v1/login/otp/createOtp', params=params, headers=headers, verify=False)
    return response
