import requests
import random

def call(sdt):
    headers = {
    'Host': 'api.ahamove.com',
    'User-Agent': f'Android/25 AhaMove_User/{random.randint(100000, 999999)} asus/ASUS_Z01QD',
    'Accepts-Version': '2',
    'Authorization': 'Bearer null',
    'Content-Type': 'application/json; charset=UTF-8',
    # 'Content-Length': '101',
    # 'Accept-Encoding': 'gzip, deflate',
    }
    
    params = {
        'lang': 'vi',
    }
    
    json_data = {
        'country_code': 'VN',
        'firebase_sms_auth': False,
        'mobile': sdt,
        'resend': True,
        'type': 'android',
    }
    
    response = requests.post(
        'https://api.ahamove.com/api/v3/public/user/login',
        params=params,
        headers=headers,
        json=json_data,
        verify=False,
    )
    return response