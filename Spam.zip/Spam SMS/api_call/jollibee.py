import requests

def call(sdt):
    cookies = {
        'PHPSESSID': 'dkmvp0dj7kvs4gr0tjk44ubsdm',
        'mage-cache-storage': '%7B%7D',
        'mage-cache-storage-section-invalidation': '%7B%7D',
        'mage-cache-sessid': 'true',
        'form_key': 'Js74ET20hvRrtYw8',
        'mage-messages': '',
        'recently_viewed_product': '%7B%7D',
        'recently_viewed_product_previous': '%7B%7D',
        'recently_compared_product': '%7B%7D',
        'recently_compared_product_previous': '%7B%7D',
        'product_data_storage': '%7B%7D',
        'csp': '2',
        'csd': '25',
        'private_content_version': '6b916b7632183549972a79bef2f9185f',
        'section_data_ids': '%7B%22amfacebook-pixel%22%3A1718067566%2C%22apptrian_tiktokpixelapi_matching_section%22%3A1718067566%2C%22notification_count%22%3A1718067566%2C%22product_area_price%22%3A1718067551%2C%22messages%22%3Anull%2C%22customer%22%3Anull%2C%22compare-products%22%3Anull%2C%22last-ordered-items%22%3Anull%2C%22cart%22%3Anull%2C%22directory-data%22%3Anull%2C%22captcha%22%3Anull%2C%22instant-purchase%22%3Anull%2C%22loggedAsCustomer%22%3Anull%2C%22persistent%22%3Anull%2C%22review%22%3Anull%2C%22wishlist%22%3Anull%2C%22ammessages%22%3Anull%2C%22customer_voucher%22%3Anull%2C%22recently_viewed_product%22%3Anull%2C%22recently_compared_product%22%3Anull%2C%22product_data_storage%22%3Anull%2C%22paypal-billing-agreement%22%3Anull%7D',
    }

    headers = {
        'accept': '*/*',
        'accept-language': 'vi,vi-VN;q=0.9,en;q=0.8',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        # 'cookie': 'PHPSESSID=dkmvp0dj7kvs4gr0tjk44ubsdm; mage-cache-storage=%7B%7D; mage-cache-storage-section-invalidation=%7B%7D; mage-cache-sessid=true; form_key=Js74ET20hvRrtYw8; mage-messages=; recently_viewed_product=%7B%7D; recently_viewed_product_previous=%7B%7D; recently_compared_product=%7B%7D; recently_compared_product_previous=%7B%7D; product_data_storage=%7B%7D; csp=2; csd=25; private_content_version=6b916b7632183549972a79bef2f9185f; section_data_ids=%7B%22amfacebook-pixel%22%3A1718067566%2C%22apptrian_tiktokpixelapi_matching_section%22%3A1718067566%2C%22notification_count%22%3A1718067566%2C%22product_area_price%22%3A1718067551%2C%22messages%22%3Anull%2C%22customer%22%3Anull%2C%22compare-products%22%3Anull%2C%22last-ordered-items%22%3Anull%2C%22cart%22%3Anull%2C%22directory-data%22%3Anull%2C%22captcha%22%3Anull%2C%22instant-purchase%22%3Anull%2C%22loggedAsCustomer%22%3Anull%2C%22persistent%22%3Anull%2C%22review%22%3Anull%2C%22wishlist%22%3Anull%2C%22ammessages%22%3Anull%2C%22customer_voucher%22%3Anull%2C%22recently_viewed_product%22%3Anull%2C%22recently_compared_product%22%3Anull%2C%22product_data_storage%22%3Anull%2C%22paypal-billing-agreement%22%3Anull%7D',
        'dnt': '1',
        'newrelic': 'eyJ2IjpbMCwxXSwiZCI6eyJ0eSI6IkJyb3dzZXIiLCJhYyI6IjM0MjA2MDQiLCJhcCI6IjEzODU5MjEyNzYiLCJpZCI6IjcwNjQ2NjU4ZDNlYjQ5NDkiLCJ0ciI6IjYyODQ2MTY4ZmU1ZjU5ZTY3NDg3MDAzZjUyY2RkODE3IiwidGkiOjE3MTgwNjY2MTMxMzV9fQ==',
        'origin': 'https://jollibee.com.vn',
        'priority': 'u=1, i',
        'referer': 'https://jollibee.com.vn/customer/account/create/',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'traceparent': '00-62846168fe5f59e67487003f52cdd817-70646658d3eb4949-01',
        'tracestate': '3420604@nr=0-1-3420604-1385921276-70646658d3eb4949----1718066613135',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'x-newrelic-id': 'VwIFUVBTDBABV1FaDwAOUFUD',
        'x-requested-with': 'XMLHttpRequest',
    }

    data = {
        'form_key': 'Js74ET20hvRrtYw8',
        'success_url': '',
        'error_url': '',
        'lastname': 'hoa',
        'firstname': 'hao',
        'phone': sdt,
        'email': 'apispamsms@gmail.com',
        'password': '8H5FicS@szUmQF7',
        'password_confirmation': '8H5FicS@szUmQF7',
        'dob': '08/04/1976',
        'gender': '2',
        'province_customer': '2',
        'agreement': '1',
        'otp_type': 'create',
        'ip': '14.168.56.217',
    }

    response = requests.post('https://jollibee.com.vn/otp/action/getOTP', cookies=cookies, headers=headers, data=data)
    return response
