import requests

def call(sdt):
    headers = {
        'Host': 'api8.viettelpay.vn',
        'Product': 'VIETTELPAY',
        'Accept-Language': 'vi',
        'Authority-Party': 'APP',
        'Channel': 'APP',
        'Type-Os': 'android',
        'App-Version': '6.8.18',
        'Os-Version': '7.1.2',
        'Imei': 'VTP_DAABF3BEB6673367B17444EBE58A6441',
        'X-Request-Id': '20240613042707',
        'Content-Type': 'application/json; charset=UTF-8',
        # 'Content-Length': '194',
        # 'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'okhttp/4.10.0',
    }

    json_data = {
        'hash': '',
        'identityType': 'msisdn',
        'identityValue': sdt,
        'imei': '',
        'notifyToken': '',
        'otp': 'android',
        'pin': '',
        'transactionId': '',
        'type': 'REGISTER',
        'typeOs': 'android',
        'verifyMethod': 'sms',
    }

    response = requests.post('https://api8.viettelpay.vn/customer/v2/accounts/register', headers=headers, json=json_data, verify=False)
    return response


