import requests

def call(sdt):
    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'en-US,en;q=0.9',
        'channel_id': '1',
        'content-type': 'application/x-www-form-urlencoded',
        'lang': 'vi',
        'origin': 'https://h5.aalive.io',
        'priority': 'u=1, i',
        'referer': 'https://h5.aalive.io/',
        'sec-ch-ua': '"Not A(Brand";v="8", "Chromium";v="132", "Microsoft Edge";v="132"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'timestamp': '1738492936',
        'token': '',
        'tokenx': 'c04b5202563fc56eb9da7c8a34eb50e0',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 Edg/132.0.0.0',
    }

    data = {
        'mobile': sdt,
        'area_code': '84',
        'token': '',
        'channel_id': '1',
    }

    response = requests.post('https://liveapi.aalive.io/v2/user/sendLoginMobileCode', headers=headers, data=data)
    return response
