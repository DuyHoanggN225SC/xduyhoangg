import requests

def call(sdt):
    headers = {
        'Host': 'otp-verify.okd.viettelpost.vn',
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json;charset=utf-8',
        # 'Content-Length': '84',
        # 'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'okhttp/4.9.0',
    }

    json_data = {
        'account': sdt,
        'function': 'SSO_REGISTER',
        'type': 'PHONE',
        'otpType': 'NUMBER',
    }

    response = requests.post('https://otp-verify.okd.viettelpost.vn/api/otp/sendOTP', headers=headers, json=json_data, verify=False)
    return response

