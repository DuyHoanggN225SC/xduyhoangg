import requests

def call(sdt):
    cookies = {
                'img-ext': 'avif',
                'NEXT_LOCALE': 'vi',
                'device-id': 's%3Aweb_a2d88d8a-30a6-45e7-a176-3bde426dee6b.sCh7MaenWcB%2BrjSBjp4EToxTJqyLTr3o2XhEErCxeWs',
                'shared-device-id': 'web_a2d88d8a-30a6-45e7-a176-3bde426dee6b',
                'screen-size': 's%3A1920x1080.uvjE9gczJ2ZmC0QdUMXaK%2BHUczLAtNpMQ1h3t%2Fq6m3Q',
                'G_ENABLED_IDPS': 'google',
                'session-id': 's%3Aa074faba-8b7c-4de6-820d-93b0f980ca4e.NXEZ1PPg6ZOe0Uau96qLQ7Gn7UG%2BpsTq%2FVvFKOs3S8U',
                'remember-user': '',
        }

    headers = {
                'accept': 'application/json, text/plain, */*',
                'accept-language': 'vi,vi-VN;q=0.9,en;q=0.8',
                'content-type': 'application/json',
                # 'cookie': 'img-ext=avif; NEXT_LOCALE=vi; device-id=s%3Aweb_a2d88d8a-30a6-45e7-a176-3bde426dee6b.sCh7MaenWcB%2BrjSBjp4EToxTJqyLTr3o2XhEErCxeWs; shared-device-id=web_a2d88d8a-30a6-45e7-a176-3bde426dee6b; screen-size=s%3A1920x1080.uvjE9gczJ2ZmC0QdUMXaK%2BHUczLAtNpMQ1h3t%2Fq6m3Q; G_ENABLED_IDPS=google; session-id=s%3Aa074faba-8b7c-4de6-820d-93b0f980ca4e.NXEZ1PPg6ZOe0Uau96qLQ7Gn7UG%2BpsTq%2FVvFKOs3S8U; remember-user=',
                'dnt': '1',
                'origin': 'https://tv360.vn',
                'priority': 'u=1, i',
                'referer': 'https://tv360.vn/login?r=https%3A%2F%2Ftv360.vn%2F',
                'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'starttime': '1717772989877',
                'tz': 'Asia/Saigon',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        }

    json_data = {
                'msisdn': sdt,
        }

    response = requests.post('https://tv360.vn/public/v1/auth/get-otp-login', cookies=cookies, headers=headers, json=json_data)
    return response
