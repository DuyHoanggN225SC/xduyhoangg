import requests
import json
import random
import string
sdt = "0399962319"
cookies = {
    'aws-waf-token': '9ee2ec9d-1946-45b6-bea5-6ea3552a5e1d:BgoAdJVSL9FrAAAA:TEGv09rhe8vsvLnF5CeWoeAWQ0RuL3Uz4UsyAaxNI9gn+BXjBnDfsmmhubGBkhau9ts6gm+RhFxa5NF6ITC0LfJKgZStR/i3pNm6OJk4ajF2dxe1ig==',
}

headers = {
    'Host': 'api.usr.traveloka.com',
    'Accept': 'application/json',
    'Origin': 'm.traveloka.com',
    'Date': '2025-03-30 18:47',
    'Content-Type': 'application/json; charset=utf-8',
    # 'Content-Length': '916',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'User-Agent': 'okhttp/4.11.0',
    # 'Cookie': 'aws-waf-token=9ee2ec9d-1946-45b6-bea5-6ea3552a5e1d:BgoAdJVSL9FrAAAA:TEGv09rhe8vsvLnF5CeWoeAWQ0RuL3Uz4UsyAaxNI9gn+BXjBnDfsmmhubGBkhau9ts6gm+RhFxa5NF6ITC0LfJKgZStR/i3pNm6OJk4ajF2dxe1ig==',
}

json_data = {
    'clientInterface': 'mobile-android',
    'context': {
        'nonce': '75f07893-0172-4efb-9fe8-0cdbd12c60f7',
        'tvLifetime': 'YPdgGXbAmhtBYdVl+7HNNhaMAdcIVEpBsFEZ3ui/mu8m8v1qt9fiXac9rKAhCoMEI6vflVfRVvML+gztxDQycUFePDo5KT43Ldiz0SA+barXcxtmwFP9//uzSa8kHWG31rneoR5p/LypD5dSlWn/ZzJROG6OMA2B9bk3oBlUav/jIPv89k3DyuiRa/jYZznOGtb00o26n5r9A1Rn72c8sk6Rv6oQsKzjQrDz4omO/JgbM/gwdSCe6h5etW+cokAEKYYIJnp6FKo=~djAy',
        'tvSession': 'XWCG1r1uygJz9oY5hP4kKyaPyy49SSwcpcJzcPCGxmICzvWAu5W1P+fbUUeQQIfYzI3fBcCDKDvOp/6fH/AqLUn0lz1g2C4rDfsOkc4ZkEVkXhqKx/I0lsDKaKo85za6EAJQxMgdsfnauxSCK5vvreZFLxmdgj0dWq3dH24+oRyLb8ThTngCJDwsS7jpuzzEIJhOHinPNhqGXKTYl7/s5X6e/A6y04A4JAQcYt259KL1FAk5GeIQQijJCloes9JKvITR2P7HLBXwiWCEQEXVmo2gwYIbmDRccAOPyKH4GJFfd5acxFisfU9uAIqr1eRtLEY+haEQCgu2IZmVvPG0nSrmpRaDyJtkEQRfXR5xXeOjK2cSdVEm9YhTb/btGhRAw7FSBI4ZcHPCyyNiaLZz5AvfNBohHB0lJHvZcpFcoRV0bHg=~djAy',
    },
    'data': {
        'userLoginMethod': 'PN',
        'username': '+84399297654',
    },
    'fields': [],
}

response = requests.post(
    'https://api.usr.traveloka.com/vi-vn/v2/user/signup',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)
print(response.text)